# frozen_string_literal: true

title 'Logging and Monitoring'

control '5.1.5' do
  title 'Ensure the storage container storing the activity logs is not publicly accessible'
  impact 1.0
  tag cis: 'azure:5.1.5'
  tag level: 1
  desc <<-DESC
    The storage account container containing the activity log export should not be publicly accessible.

    Allowing public access to activity log content may aid an adversary in
    identifying weaknesses in the affected account's use or configuration.
  DESC

  profiles = azurerm_monitor_log_profiles
  describe profiles do
    its('names') { should_not be_empty }
  end

  profiles.names.each do |name|
    sa = azurerm_monitor_log_profile({ name: name }).storage_account
    # Activity logs are stored in blob container named `insights-operational-logs`
    container = 'insights-operational-logs'
    describe azurerm_storage_account_blob_container(resource_group: sa[:resource_group],
                                                    storage_account_name: sa[:name],
                                                    blob_container_name: container) do
      its('properties.publicAccess') { should cmp 'None' }
    end
  end
end
