# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.3' do
  title "Ensure that 'Auditing' Retention is 'greater than 90 days'"
  impact 1.0
  tag cis: 'azure:4.3'
  tag level: 1
  desc <<-DESC
    SQL Server Audit Retention should be configured to be greater than 90 days.

    Audit Logs can be used to check for anomalies and give insight into
    suspected breaches or misuse of information and access.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name).auditing_settings do
        its('properties')               { should have_attributes(state: 'Enabled') }
        its('properties.retentionDays') { should cmp >= 90 }
      end
    end
  end
end
