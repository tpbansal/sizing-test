# frozen_string_literal: true

title 'Security Center'

control '2.19' do
  title "Ensure that 'Send email also to subscription owners' is set to 'On'"
  impact 1.0
  tag cis: 'azure:2.19'
  tag level: 1
  desc <<-DESC
    Enable security alerts emailing to subscription owners.

    Rationale: Enabling security alerts emailing to subscription owners ensures
    that they receive the security alert emails from Microsoft. This ensures that
    they are aware of any potential security issues and can timely mitigate the
    risk.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('send_security_email_to_admin') { should be true }
  end
end
