# frozen_string_literal: true

title 'Identity and Access Management'

control '1.20' do
  title "Ensure that 'Users who can manage Office 365 groups' is set to 'None'"
  impact 1.0
  tag cis: 'azure:1.20'
  tag level: 2
  desc <<-DESC
    Restrict Office 365 group management to administrators only.

    Restricting Office 365 group management to administrators only
    does not allow users to make changes to Office 365 groups. This
    ensures that Office 365 groups are appropriately managed and
    their management is not delegated to any other user.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Groups
    3. Go to General settings
    4. Ensure that Groups who can manage Office 365 groups is set to None'
  end
end
