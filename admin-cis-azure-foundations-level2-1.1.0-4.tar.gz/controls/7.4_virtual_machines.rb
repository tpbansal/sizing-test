# frozen_string_literal: true

resource_groups     = attribute('provided_resource_group', value: azurerm_resource_groups.names)
approved_extensions = attribute('approved_extensions',
                                value: [],
                                description: 'List of approved extensions.')

title 'Virtual Machines'

control '7.4' do
  title 'Ensure that only approved extensions are installed'
  impact 1.0
  tag cis: 'azure:7.4'
  tag level: 1
  desc <<-DESC
    Azure virtual machine extensions are small applications that provide
    post-deployment configuration and automation tasks on Azure virtual
    machines. These extensions run with administrative privileges and could
    potentially access anything on your virtual machine. Azure portal and
    community provide several such extensions. Your organization should
    carefully evaluate such extensions and ensure that only those that are
    approved for use are actually used.
  DESC

  # This control will be skipped until you pass in a list of approved
  # extensions using the --attrs flag. If you are running from Automate you
  # will need to make a copy of this profile and add your approved extensions
  # to the attribute at the top of this file and setup your scans to run
  # against your copy of the profile.
  only_if('No Approved Extensions provided.') { approved_extensions.any? }

  resource_groups.each do |resource_group|
    azurerm_virtual_machines(resource_group: resource_group).vm_names.each do |name|
      describe azurerm_virtual_machine(resource_group: resource_group, name: name) do
        it { should have_only_approved_extensions(approved_extensions) }
      end
    end
  end
end
