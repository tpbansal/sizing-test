# frozen_string_literal: true

title 'App Service'

java_apps = []
azurerm_resource_groups.names.each do |resource_group|
  azurerm_webapps(resource_group: resource_group).names.each do |app_name|
    app = azurerm_webapp(resource_group: resource_group, name: app_name)
    java_apps << app unless app.stack_version('java').nil?
  end
end

control '9.9' do
  title 'Ensure that Java version is the latest, if used to run the web app'
  impact 1.0
  tag cis: 'azure:9.9'
  tag level: 1
  desc <<-DESC
    Periodically, newer versions are released for Java software either due to security flaws or to include
    additional functionality. Using the latest Java version for web apps is recommended in order to take advantage
    of security fixes, if any, and/or new functionalities of the newer version.
  DESC

  # Skip if no Java apps are found.
  only_if('No Java Apps found.') { !java_apps.empty? }
  java_apps.each do |java_app|
    describe java_app do
      it { should be_using_latest('java') }
    end
  end
end
