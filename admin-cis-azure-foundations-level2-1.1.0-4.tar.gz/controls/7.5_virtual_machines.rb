# frozen_string_literal: true

title 'Virtual Machines'

control '7.5' do
  title 'Ensure that the latest OS Patches for all Virtual Machines are applied'
  impact 1.0
  tag cis: 'azure:7.5'
  tag level: 1
  desc <<-DESC
    Windows and Linux virtual machines should be kept updated to

    * Address a specific bug or flaw
    * Improve an OS or application’s general stability
    * Fix a security vulnerability

    Azure Security Center retrieves a list of available security and critical updates
    from Windows Update or Windows Server Update Services (WSUS), depending on which
    service is configured on a Windows VM. Security Center also checks for the latest
    updates in Linux systems. If your VM is missing a system update, Security Center
    will recommend that you apply system updates.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:

    On the Azure Console:

    1. Go to Security Center - Recommendations
    2. Ensure that there are no recommendations for Apply system updates

    Alternatively, you can employ your own patch assessment and management tool to periodically assess,
    report and install the required security patches for your OS.'
  end
end
