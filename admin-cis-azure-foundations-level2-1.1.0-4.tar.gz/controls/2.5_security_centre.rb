# frozen_string_literal: true

title 'Security Center'

control '2.5' do
  title "Ensure ASC Default policy setting 'Monitor Endpoint Protection' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.5'
  tag level: 1
  desc <<-DESC
    Enable Endpoint protection recommendations for virtual machines.

    Rationale: When this setting is enabled, it recommends endpoint protection be
    provisioned for all Windows virtual machines to help identify and remove
    viruses, spyware, and other malicious software.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:endpointProtectionMonitoringEffect) }
    its('default_policy.properties.parameters.endpointProtectionMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
