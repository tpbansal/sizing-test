# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Networking'

control '6.3' do
  title 'Ensure no SQL Databases allow ingress 0.0.0.0/0 (ANY IP)'
  impact 1.0
  tag cis: 'azure:6.3'
  tag level: 1
  desc <<-DESC
    Ensure that no SQL Databases allow ingress from 0.0.0.0/0 (ANY IP).

    SQL Server includes a firewall to block access to unauthorized connections.
    More granular IP addresses can be defined by referencing the range of
    addresses available from specific datacenters.

    By default, for a SQL server, a Firewall exists with StartIp of 0.0.0.0
    and EndIP of 0.0.0.0 allowing access to all the Azure services.

    Additionally, a custom rule can be set up with StartIp of 0.0.0.0
    and EndIP of 255.255.255.255 allowing access from ANY IP over the Internet.

    In order to reduce the potential attack surface for a SQL server, firewall rules
    should be defined with more granular IP addresses by referencing the range of
    addresses available from specific data-centers.

    NOTE:
    Firewall rules configured on individual SQL Database using Transact-sql overrides 
    the rules set on SQL server. Azure does not provides any Powershell, API, CLI or 
    Portal option to check database level firewall rules and so far Transact-SQL is 
    the only way to check for the same. For comprehensive control over egress traffic 
    on SQL Databases, Firewall rules should be checked using a SQL client.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      sql_server_firewall = azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name).firewall_rules

      if sql_server_firewall.empty?
        describe sql_server_firewall do
          it { should be_empty }
        end
      else
        sql_server_firewall.each do |firewall_rule|
          describe firewall_rule do
            its('properties') { should_not have_attributes(startIpAddress: '0.0.0.0', endIpAddress: '0.0.0.0') }
            its('properties') { should_not have_attributes(startIpAddress: '0.0.0.0', endIpAddress: '255.255.255.255') }
          end
        end
      end
    end
  end
end
