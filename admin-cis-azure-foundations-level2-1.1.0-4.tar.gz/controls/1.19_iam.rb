# frozen_string_literal: true

title 'Identity and Access Management'

control '1.19' do
  title "Ensure that 'Users can create Office 365 groups' is set to 'No'"
  impact 1.0
  tag cis: 'azure:1.19'
  tag level: 2
  desc <<-DESC
    Restrict Office 365 group creation to administrators only.

    Restricting Office 365 group creation to administrators only
    ensures that there is no proliferation of such groups. Appropriate
    groups should be created and managed by the administrator and such
    rights should not be delegated to any other user.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Groups
    3. Go to General settings
    4. Ensure that Users can create Office 365 groups is set to No'
  end
end
