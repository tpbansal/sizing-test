# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.14' do
  title "Ensure server parameter 'log_connections' is set to 'ON' for PostgreSQL Database Server"
  impact 1.0
  tag cis: 'azure:4.14'
  tag level: 1
  desc <<-DESC
    Enable log_connections on PostgreSQL Servers.

    Enabling log_connections helps PostgreSQL Database to log attempted connection to the server,
    as well as successful completion of client authentication. Log data can be used to identify,
    troubleshoot, and repair configuration errors and suboptimal performance.
  DESC

  resource_groups.each do |resource_group|
    azurerm_postgresql_servers(resource_group: resource_group).names.each do |server_name|
      describe azurerm_postgresql_server(resource_group: resource_group, server_name: server_name) do
        its('configurations') { is_expected.to respond_to(:log_connections) }
        its('configurations.log_connections.properties.value') { should cmp 'On' }
      end
    end
  end
end
