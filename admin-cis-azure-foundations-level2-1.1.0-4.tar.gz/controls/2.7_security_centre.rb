# frozen_string_literal: true

title 'Security Center'

control '2.7' do
  title "Ensure ASC Default policy setting 'Monitor Network Security Groups' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.7'
  tag level: 1
  desc <<-DESC
    Enable Network security groups recommendations for virtual machines.

    Rationale: When this setting is enabled, it recommends that network security
    groups be configured to control inbound and outbound traffic to VMs that have
    public endpoints. Network security groups that are configured for a subnet is
    inherited by all virtual machine network interfaces unless otherwise
    specified. In addition to checking that a network security group has been
    configured, this policy assesses inbound security rules to identify rules
    that allow incoming traffic.
  DESC

  describe 'skip' do
    skip 'Deprecated. Network Security Group Monitoring can no longer be managed by Azure Default Security Policy.
    '
  end
end
