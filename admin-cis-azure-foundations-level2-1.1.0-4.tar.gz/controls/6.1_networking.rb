# frozen_string_literal: true#

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Networking'

control '6.1' do
  title 'Ensure that RDP access is restricted from the internet'
  impact 1.0
  tag cis: 'azure:6.1'
  tag level: 1
  desc <<-DESC
    Disable RDP access on Network Security Groups from Internet

    Rationale: The potential security problem with using RDP over the Internet
    is that attackers can use various brute force techniques to gain access to
    Azure Virtual Machines. Once the attackers gain access, they can use your
    virtual machine as a launch point for compromising other machines on your
    Azure Virtual Network or even attack networked devices outside of Azure.
  DESC

  resource_groups.each do |resource_group|
    azurerm_network_security_groups(resource_group: resource_group).names.each do |sg_name|
      describe azurerm_network_security_group(resource_group: resource_group, name: sg_name) do
        it { should_not allow_rdp_from_internet }
      end
    end
  end
end
