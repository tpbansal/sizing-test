# frozen_string_literal: true

title 'App Service'

control '9.1' do
  title 'Ensure App Service Authentication is set on Azure App Service'
  impact 1.0
  tag cis: 'azure:9.1'
  tag level: 1
  desc <<-DESC
    Azure App Service Authentication is a feature that can prevent anonymous HTTP requests from reaching the API app,
    or authenticate those that have tokens before they reach the API app.
    If an anonymous request is received from a browser, App Service will redirect to a logon page.
    To handle the logon process, a choice from a set of identity providers can be made,
    or a custom authentication mechanism can be implemented.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_webapps(resource_group: resource_group).names.each do |webapp|
      describe azurerm_webapp(resource_group: resource_group, name: webapp) do
        its('auth_settings.properties') { should have_attributes(enabled: true) }
      end
    end
  end
end
