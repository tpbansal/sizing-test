# frozen_string_literal: true

resource_groups     = attribute('provided_resource_group', value: azurerm_resource_groups.names)
approved_extensions = attribute('approved_extensions',
                                value: [],
                                description: 'List of approved extensions.')
windows_endpoint_protection = attribute('windows_endpoint_protection',
                                        value: [],
                                        description: 'List of available endpoint protection extensions for Windows.')
linux_endpoint_protection   = attribute('linux_endpoint_protection',
                                        value: [],
                                        description: 'List of available endpoint protection extensions for Linux.')
title 'Virtual Machines'

control '7.6' do
  title 'Ensure that the endpoint protection for all Virtual Machines is installed'
  impact 1.0
  tag cis: 'azure:7.6'
  tag level: 1
  desc <<-DESC
    Installing endpoint protection systems (like Antimalware for Azure) provides
    for real-time protection capability that helps identify and remove viruses,
    spyware, and other malicious software, with configurable alerts when known
    malicious or unwanted software attempts to install itself or run on your
    Azure systems.
  DESC

  # This control will be skipped until you pass in a list of endpoint
  # protection extensions using the --attrs flag. If you are running from
  # Automate you will need to make a copy of this profile and add your endpoint
  # protection extensions to the attribute at the top of this file and setup
  # your scans to run against your copy of the profile.
  #
  # Windows & Linux both have separate Extension Types for Endpoint Protection,
  # so the required endpoint protection types must be provided separately.
  only_if('No Approved Extensions provided.') { approved_extensions.any? }

  resource_groups.each do |resource_group|

    azurerm_virtual_machines(resource_group: resource_group).where(platform: 'windows').vm_names.each do |name|
      describe azurerm_virtual_machine(resource_group: resource_group, name: name) do
        it { should have_endpoint_protection_installed(windows_endpoint_protection) }
      end
    end

    azurerm_virtual_machines(resource_group: resource_group).where(platform: 'linux').vm_names.each do |name|
      describe azurerm_virtual_machine(resource_group: resource_group, name: name) do
        it { should have_endpoint_protection_installed(linux_endpoint_protection) }
      end
    end
  end
end
