# frozen_string_literal: true

title 'Logging and Monitoring'
control '5.2.2' do
  title 'Ensure that Activity Log Alert exists for Create or Update Network Security Group'
  impact 1.0
  tag cis: 'azure:5.2.2'
  tag level: 1
  desc <<-DESC
    Create an Activity Log Alert for the "Create" or "Update Network Security Group" event.

    Monitoring for "Create" or "Update Network Security Group" events gives
    insight into network access changes and may reduce the time it takes to detect suspicious activity.
  DESC

  required_scope = "/subscriptions/#{azurerm_subscription.id}"

  alerts = azurerm_monitor_activity_log_alerts
           .where { operations.include?('Microsoft.Network/networkSecurityGroups/write') }
           .where { location.include?('Global') }

  describe alerts do
    its('entries') { should_not be_empty }
  end

  describe.one do
    alerts.entries.each do |a|
      alert  = azurerm_monitor_activity_log_alert(resource_group: a.resource_group, name: a.name)
      # Scope can either have a trailing slash or not and be compliant.
      describe alert do
        it            { should exist }
        it            { should be_enabled }
        its('scopes') { should include required_scope}
      end
      describe alert do
        it            { should exist }
        it            { should be_enabled }
        its('scopes') { should include required_scope+"/"}
      end
    end
  end
end
