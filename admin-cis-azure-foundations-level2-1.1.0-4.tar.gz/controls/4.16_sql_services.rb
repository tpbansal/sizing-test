# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.16' do
  title "Ensure server parameter 'log_duration' is set to 'ON' for PostgreSQL Database Server"
  impact 1.0
  tag cis: 'azure:4.16'
  tag level: 1
  desc <<-DESC
    Enable log_duration on PostgreSQL Servers.

    Enabling log_duration helps the PostgreSQL Database to Logs the duration of each completed SQL
    statement which in turn generates query and error logs. Query and error logs can be used to identify,
    troubleshoot, and repair configuration errors and sub-optimal performance.
  DESC

  resource_groups.each do |resource_group|
    azurerm_postgresql_servers(resource_group: resource_group).names.each do |server_name|
      describe azurerm_postgresql_server(resource_group: resource_group, server_name: server_name) do
        its('configurations') { is_expected.to respond_to(:log_duration) }
        its('configurations.log_duration.properties.value') { should cmp 'On' }
      end
    end
  end
end
