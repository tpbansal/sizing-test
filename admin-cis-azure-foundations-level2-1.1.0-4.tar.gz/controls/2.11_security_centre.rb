# frozen_string_literal: true

title 'Security Center'

control '2.11' do
  title "Ensure ASC Default policy setting 'Monitor Storage Blob Encryption' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.11'
  tag level: 1
  desc <<-DESC
    Enable Storage Encryption recommendations.

    Rationale: When this setting is enabled, any new data in Azure Blobs and
    Files will be encrypted.
  DESC

  describe 'Auto-Pass' do
    skip 'Automatically Compliant:

    Azure Storage is encrypted by default now and cannot be unencrypted.
    Therefore, the Enable encryption of storage account recommendation and
    its corresponding policy have been removed.

    For more information, see https://azure.microsoft.com/en-gb/updates/storage-account-encrypt-default/
    '
  end
end
