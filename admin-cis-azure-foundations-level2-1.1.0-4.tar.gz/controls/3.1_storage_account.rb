# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Storage Accounts'

control '3.1' do
  title "Ensure that 'Secure transfer required' is set to 'Enabled'"
  impact 1.0
  tag cis: 'azure:3.1'
  tag level: 1
  desc <<-DESC
    Enable data encryption in transit.

    The secure transfer option enhances the security of your storage account
    by only allowing requests to the storage account by a secure connection.
  DESC

  resource_groups.each do |resource_group|
    azurerm_storage_accounts(resource_group: resource_group).names.each do |storage_account_name|
      describe azurerm_storage_account(resource_group: resource_group, name: storage_account_name) do
        its('properties') { should have_attributes(supportsHttpsTrafficOnly: true) }
      end
    end
  end
end
