# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Storage Accounts'

control '3.3' do
  title 'Ensure Storage logging is enabled for Queue service for read, write, and delete requests'
  impact 1.0
  tag cis: 'azure:3.3'
  tag level: 2
  desc <<-DESC
    Storage Analytics logs contain detailed information about successful and failed requests to a
    storage service. This information can be used to monitor individual requests and to diagnose
    issues with a storage service. Requests are logged on a best-effort basis.

    Storage Analytics logging is not enabled by default for your storage account.
  DESC

  resource_groups.each do |resource_group|
    azurerm_storage_accounts(resource_group: resource_group).names.each do |storage_account_name|
      account = azurerm_storage_account(resource_group: resource_group, name: storage_account_name)
      next if account.queues.nil?
      describe account do
        it                              { is_expected.to respond_to(:queue_properties) }
        its('queue_properties')         { is_expected.to respond_to(:logging) }
        its('queue_properties.logging') { should have_attributes(read: 'true', write: 'true', delete: 'true') }
      end
    end
  end
end
