# frozen_string_literal: true

title 'App Service'

python_apps = []
azurerm_resource_groups.names.each do |resource_group|
  azurerm_webapps(resource_group: resource_group).names.each do |app_name|
    app = azurerm_webapp(resource_group: resource_group, name: app_name)
    python_apps << app unless app.stack_version('python').nil?
  end
end

control '9.8' do
  title 'Ensure that Python version is the latest, if used to run the web app'
  impact 1.0
  tag cis: 'azure:9.8'
  tag level: 1
  desc <<-DESC
    Periodically, newer versions are released for Python software either due to security flaws or
    to include additional functionality. Using the latest Python version for web apps is recommended
    in order to take advantage of security fixes, if any, and/or additional functionalities of
    the newer version.
  DESC

  # Skip if no Python apps are found.
  only_if('No Python Apps found.') { !python_apps.empty? }
  python_apps.each do |python_app|
    describe python_app do
      it { should be_using_latest('python') }
    end
  end
end
