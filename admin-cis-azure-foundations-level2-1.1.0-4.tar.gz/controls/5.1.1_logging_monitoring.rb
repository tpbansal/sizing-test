# frozen_string_literal: true

title 'Logging and Monitoring'

control '5.1.1' do
  title 'Ensure that a Log Profile exists'
  impact 1.0
  tag cis: 'azure:5.1.1'
  tag level: 1
  desc <<-DESC
    Enable log profile for exporting activity logs.

    A Log Profile controls how your Activity Log is exported. By default, activity
    logs are retained only for 90 days. It is thus recommended to define a log profile
    using which you could export the logs and store them for a longer duration for analyzing
    security activities within your Azure subscription.
  DESC

  profiles = azurerm_monitor_log_profiles
  describe profiles do
    its('names') { should_not be_empty }
  end

  profiles.names.each do |profile|
    describe azurerm_monitor_log_profile(name: profile) do
      it { should exist }
      its('retention_enabled') { should be true }
      it { should have_log_retention_enabled }
    end
  end
end
