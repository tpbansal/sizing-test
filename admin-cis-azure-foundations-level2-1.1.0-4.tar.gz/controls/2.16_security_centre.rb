# frozen_string_literal: true

title 'Security Center'

control '2.16' do
  title "Ensure that 'Security contact emails' is set"
  impact 1.0
  tag cis: 'azure:2.16'
  tag level: 1
  desc <<-DESC
    Provide a security contact email address.

    Rationale: Microsoft reaches out to the provided security contact in case its
    security team finds that your resources are compromised. This ensures that
    you are aware of any potential compromise and you can timely mitigate the
    risk.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('contact_emails') { should_not be_empty }
  end
end
