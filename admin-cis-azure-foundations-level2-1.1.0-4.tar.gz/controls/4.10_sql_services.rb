# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.10' do
  title "Ensure SQL server's TDE protector is encrypted with BYOK (Use your own key)"
  impact 1.0
  tag cis: 'azure:4.10'
  tag level: 2
  desc <<-DESC
    Bring Your Own Key (BYOK) support for Transparent Data Encryption (TDE) allows user control of TDE
    encryption keys and restricts who can access them and when. Azure Key Vault, Azure’s cloud-based
    external key management system is the first key management service where TDE has integrated
    support for BYOK. With BYOK, the database encryption key is protected by an asymmetric key
    stored in the Key Vault. The asymmetric key is set at the server level and inherited by all
    databases under that server. This feature is currently in preview and we do not recommend
    using it for production workloads until we declare General Availability.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name) do
        its('encryption_protector')                      { should_not be_nil }
        its('encryption_protector.first.kind')           { should eq 'azurekeyvault' }
        its('encryption_protector.first.properties')     { should have_attributes(serverKeyType: 'AzureKeyVault') }
        its('encryption_protector.first.properties.uri') { should_not be_nil }
      end
    end
  end
end
