# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.6' do
  title "Ensure that 'Send alerts to' is set"
  impact 1.0
  tag cis: 'azure:4.6'
  tag level: 2
  desc <<-DESC
    Provide the email address to which alerts will be sent upon detection of anomalous
    activities on SQL Servers.

    Providing the email address to receive alerts ensures that any detection of anomalous
    activities is reported as soon as possible, making it more likely to mitigate any potential risk sooner.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group,
                                  server_name: sql_server_name).threat_detection_settings do
        its('properties') { should have_attributes(state: 'Enabled') }
        its('properties') { should_not have_attributes(emailAddresses: ['']) }
      end
    end
  end
end
