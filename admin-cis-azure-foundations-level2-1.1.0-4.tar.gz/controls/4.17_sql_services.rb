# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.17' do
  title "Ensure server parameter 'connection_throttling' is set to 'ON' for PostgreSQL Database Server"
  impact 1.0
  tag cis: 'azure:4.17'
  tag level: 1
  desc <<-DESC
    Enable connection_throttling on PostgreSQL Servers.

    Enabling connection_throttling helps the PostgreSQL Database to Set the verbosity of
    logged messages which in turn generates query and error logs with respect to concurrent connections,
    that could lead to a successful Denial of Service (DoS) attack by exhausting connection resources.
    A system can also fail or be degraded by an overload of legitimate users. Query and error logs can be
    used to identify, troubleshoot, and repair configuration errors and sub-optimal performance.
  DESC

  resource_groups.each do |resource_group|
    azurerm_postgresql_servers(resource_group: resource_group).names.each do |server_name|
      describe azurerm_postgresql_server(resource_group: resource_group, server_name: server_name) do
        its('configurations') { is_expected.to respond_to(:connection_throttling) }
        its('configurations.connection_throttling.properties.value') { should cmp 'On' }
      end
    end
  end
end
