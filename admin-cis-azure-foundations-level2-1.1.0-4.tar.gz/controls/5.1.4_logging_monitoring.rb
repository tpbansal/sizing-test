# frozen_string_literal: true

title 'Logging and Monitoring'

control '5.1.4' do
  title 'Ensure the log profile captures activity logs for all regions including global'
  impact 1.0
  tag cis: 'azure:5.1.4'
  tag level: 1
  desc <<-DESC
    Configure the log profile to export activities from all Azure
    supported regions/locations including global.

    A log profile controls how the activity Log is exported.

    Ensuring that logs are exported from all the Azure supported regions/locations means that
    logs for potentially unexpected activities occurring in otherwise unused regions are stored
    and made available for incident response and investigations.

    Including global region/location in the log profile locations ensures all events from the
    control/management plane will be exported, as many events in the activity log are global events.
  DESC

  available_region_count = azurerm_subscription.locations.count

  profiles = azurerm_monitor_log_profiles
  describe profiles do
    its('names') { should_not be_empty }
  end

  profiles.names.each do |profile|
    describe azurerm_monitor_log_profile(name: profile) do
      its('properties.locations.count') { should be > available_region_count }
    end
  end
end
