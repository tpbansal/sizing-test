# frozen_string_literal: true

title 'Security Center'

control '2.3' do
  title "Ensure ASC Default policy setting 'Monitor System Updates' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.3'
  tag level: 1
  desc <<-DESC
    Enable Automatic provisioning of monitoring agent to collect security data.

    Rationale: When Automatic provisioning of monitoring agent is turned on, Azure Security
    Center provisions the Microsoft Monitoring Agent on all existing supported
    Azure virtual machines and any new ones that are created. The Microsoft
    Monitoring agent scans for various security-related configurations and events
    such as system updates, OS vulnerabilities, and endpoint protection and
    provides alerts.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:systemUpdatesMonitoringEffect) }
    its('default_policy.properties.parameters.systemUpdatesMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
