# frozen_string_literal: true

title 'Identity and Access Management'

control '1.8' do
  title "Ensure that 'Notify all admins when other admins reset their password?' is set to 'Yes'"
  impact 1.0
  tag cis: 'azure:1.8'
  tag level: 2
  desc <<-DESC
    Ensure that all administrators are notified if any other administrator resets their password.

    Administrator accounts are sensitive. Any password reset activity notification, when sent
    to all administrators, ensures that all administrators can passively confirm if such a
    reset is a common pattern within their group. For example, if all administrators change
    their password every 30 days, any password reset activity before that may inspect such an
    activity and confirm.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to Password reset
    4. Go to Notification
    5. Ensure that Notify all admins when other admins reset their password? is set to Yes
'
  end
end
