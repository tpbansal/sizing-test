# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Storage Accounts'

control '3.6' do
  title "Ensure that 'Public access level' is set to Private for blob containers"
  impact 1.0
  tag cis: 'azure:3.6'
  tag level: 1
  desc <<-DESC
    Disable anonymous access to blob containers.

    Anonymous, public read access to a container and its blobs can be enabled in
    Azure Blob storage. It grants read-only access to these resources without sharing
    the account key, and without requiring a shared access signature. It is recommended
    not to provide anonymous access to blob containers until, and unless, it is strongly
    desired.

    A shared access signature token should be used for providing controlled and timed access to blob containers.
  DESC

  resource_groups.each do |resource_group|
    azurerm_storage_accounts(resource_group: resource_group).names.each do |storage_account_name|
      azurerm_storage_account_blob_containers(resource_group: resource_group,
                                              storage_account_name: storage_account_name).names.each do |blob_container|
        describe azurerm_storage_account_blob_container(resource_group: resource_group,
                                                        storage_account_name: storage_account_name,
                                                        blob_container_name: blob_container) do
          its('properties') { should have_attributes(publicAccess: 'None') }
        end
      end
    end
  end
end
