# frozen_string_literal: true

title 'App Service'

dotnet_apps = []
azurerm_resource_groups.names.each do |resource_group|
  azurerm_webapps(resource_group: resource_group).names.each do |app_name|
    app = azurerm_webapp(resource_group: resource_group, name: app_name)
    dotnet_apps << app unless app.stack_version('aspnet').nil?
  end
end

control '9.6' do
  title 'Ensure that .Net Framework version is the latest, if used as a part of the web app'
  impact 1.0
  tag cis: 'azure:9.6'
  tag level: 1
  desc <<-DESC
    Periodically, newer versions are released for .Net Framework software either due to security flaws
    or to include additional functionality. Using the latest .Net framework version for web apps is
    recommended in order to to take advantage of security fixes, if any, and/or new functionalities of
    the latest version.
  DESC

  # Skip if no .Net apps are found.
  only_if('No .Net Apps found.') { !dotnet_apps.empty? }
  dotnet_apps.each do |dotnet_app|
    describe dotnet_app do
      it { should be_using_latest('aspnet') }
    end
  end
end
