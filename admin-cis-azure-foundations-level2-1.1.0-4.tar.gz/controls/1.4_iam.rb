# frozen_string_literal: true

title 'Identity and Access Management'

control '1.4' do
  title "Ensure that 'Allow users to remember multi-factor authentication on devices they trust' is 'Disabled'"
  impact 1.0
  tag cis: 'azure:1.4'
  tag level: 2
  desc <<-DESC
    Do not allow users to remember multi-factor authentication on devices.

    Remembering Multi-Factor Authentication for devices and browsers allows
    you to give users the option to by-pass MFA for a set number of days after
    performing a successful sign-in using MFA. This can enhance usability by
    minimizing the number of times a user may perform two-step verification
    on the same device. However, if an account or device is compromised,
    remembering MFA for trusted devices may affect security.

    Hence, it is recommended that MFA is not bypassed.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to All Users
    4. Click on Multi-Factor Authentication button on the top bar
    5. Click on service settings
    6. Ensure that Allow users to remember multi-factor authentication on devices they trust is not enabled'
  end
end
