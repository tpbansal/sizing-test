# frozen_string_literal: true

title 'Security Center'

control '2.15' do
  title "Ensure ASC Default policy setting 'Monitor SQL Encryption' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.15'
  tag level: 1
  desc <<-DESC
    Enable SQL Encryption recommendations.

    Rationale: When this setting is enabled, it recommends that encryption at
    rest be enabled for your Azure SQL Database, associated backups, and
    transaction log files. Even if your data is breached, it will not be
    readable.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:sqlEncryptionMonitoringEffect) }
    its('default_policy.properties.parameters.sqlEncryptionMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
