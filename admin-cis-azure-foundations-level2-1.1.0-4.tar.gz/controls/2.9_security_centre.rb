# frozen_string_literal: true

title 'Security Center'

control '2.9' do
  title "Ensure ASC Default policy setting 'Enable Next Generation Firewall(NGFW) Monitoring' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.9'
  tag level: 1
  desc <<-DESC
    Enable Next generation firewall recommendations for virtual machines.

    Rationale: When this setting is enabled, it extends network protections
    beyond network security groups, which are built into Azure. Security Center
    will discover deployments for which a next generation firewall is
    recommended and enable you to provision a virtual appliance.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:nextGenerationFirewallMonitoringEffect) }
    its('default_policy.properties.parameters.nextGenerationFirewallMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
