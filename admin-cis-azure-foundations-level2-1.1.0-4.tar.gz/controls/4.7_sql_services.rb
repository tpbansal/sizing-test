# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.7' do
  title "Ensure that 'Email service and co-administrators' is 'Enabled'"
  impact 1.0
  tag cis: 'azure:4.7'
  tag level: 2
  desc <<-DESC
    Enable service and co-administrators to receive security alerts from SQL Server.

    Providing the email address to receive alerts ensures that any detection of anomalous activities
    is reported as soon as possible, making it more likely to mitigate any potential risk sooner.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name) do
        its('threat_detection_settings.properties') {
          should have_attributes(state: 'Enabled',
                                                                             emailAccountAdmins: true)
        }
      end
    end
  end
end
