# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.1' do
  title "Ensure that 'Auditing' is set to 'On'"
  impact 1.0
  tag cis: 'azure:4.1'
  tag level: 1
  desc <<-DESC
    The Azure platform allows a SQL server to be created as a service.
    Enabling auditing at the server level ensures that all existing and newly
    created databases on the SQL server instance are audited. Auditing policy
    applied on the SQL database does not override auditing policy and settings
    applied on the particular SQL server where the database is hosted.

    Auditing tracks database events and writes them to an audit log in the Azure
    storage account. It also helps to maintain regulatory compliance, understand
    database activity, and gain insight into discrepancies and anomalies that
    could indicate business concerns or suspected security violations.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name) do
        its('auditing_settings.properties') { should have_attributes(state: 'Enabled') }
      end
    end
  end
end
