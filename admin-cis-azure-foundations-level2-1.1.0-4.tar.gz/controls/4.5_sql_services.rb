# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.5' do
  title "Ensure that 'Threat Detection types' is set to 'All'"
  impact 1.0
  tag cis: 'azure:4.5'
  tag level: 2
  desc <<-DESC
    Enable all types of threat detection on SQL Servers.

    Enabling all threat detection types, you are protected against SQL injection,
    database vulnerabilities and any other anomalous activities.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name) do
        its('threat_detection_settings.properties') { should have_attributes(state: 'Enabled', disabledAlerts: ['']) }
      end
    end
  end
end
