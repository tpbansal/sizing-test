# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.19' do
  title 'Ensure that Azure Active Directory Admin is configured'
  impact 1.0
  tag cis: 'azure:4.19'
  tag level: 1
  desc <<-DESC
    Use Azure Active Directory Authentication for authentication with SQL Database
    Rationale Statement

    Azure Active Directory authentication is a mechanism of connecting to Microsoft Azure
    SQL Database and SQL Data Warehouse by using identities in Azure Active Directory (Azure AD).
    With Azure AD authentication, you can centrally manage the identities of database users
    and other Microsoft services in one central location. Central ID management provides a single
    place to manage database users and simplifies permission management.
  DESC

  # This control is a duplicate of CIS 1.1.0 4.8 but is included for completeness.
  # See https://workbench.cisecurity.org/benchmarks/623/tickets/8795

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      sql_server = azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name)

      describe sql_server do
        its('administrators') { should_not be_empty }
      end

      sql_server.administrators.each do |admin|
        describe admin do
          its('id')         { should_not be_nil }
          its('properties') { should have_attributes(administratorType: 'ActiveDirectory') }
        end
      end
    end
  end
end
