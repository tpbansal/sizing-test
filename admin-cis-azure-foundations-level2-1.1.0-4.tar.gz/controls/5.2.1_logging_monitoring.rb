# frozen_string_literal: true

title 'Logging and Monitoring'
control '5.2.1' do
  title 'Ensure that Activity Log Alert exists for Create Policy Assignment'
  impact 1.0
  tag cis: 'azure:5.2.1'
  tag level: 1
  desc <<-DESC
    Create an Activity Log Alert for the Create Policy Assignment event.

    Monitoring for Create Policy Assignment gives insight into privilege assignment and may reduce the
    time it takes to detect a breach or misuse of information.
  DESC

  required_scope = "/subscriptions/#{azurerm_subscription.id}"

  alerts = azurerm_monitor_activity_log_alerts
           .where { operations.include?('Microsoft.Authorization/policyAssignments/write') }
           .where { location.include?('Global') }

  describe alerts do
    its('entries') { should_not be_empty }
  end

  describe.one do
    alerts.entries.each do |a|
      alert  = azurerm_monitor_activity_log_alert(resource_group: a.resource_group, name: a.name)
      # Scope can either have a trailing slash or not and be compliant.
        describe alert do
          it            { should exist }
          it            { should be_enabled }
          its('scopes') { should include required_scope}
        end
        describe alert do
          it            { should exist }
          it            { should be_enabled }
          its('scopes') { should include required_scope+"/"}
        end
    end
  end
end
