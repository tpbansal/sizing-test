# frozen_string_literal: true

title 'Identity and Access Management'

control '1.5' do
  title "Ensure that 'Number of methods required to reset' is set to '2'"
  impact 1.0
  tag cis: 'azure:1.5'
  tag level: 1
  desc <<-DESC
    Ensure that two alternate forms of identification are needed before
    allowing password reset.

    Rationale: Like multi-factor authentication, setting up dual identification
    before allowing a password reset ensures that the user identity is
    confirmed via two separate forms of identification. With dual identification
    set, an attacker would require compromising both the identity forms before
    she could maliciously reset a user's password.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:

    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to Password reset
    4. Go to Authentication methods
    5. Ensure that Number of methods required to reset is set to 2'
  end
end
