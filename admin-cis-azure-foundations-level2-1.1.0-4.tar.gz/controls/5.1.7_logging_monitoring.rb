# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Logging and Monitoring'

control '5.1.7' do
  title 'Ensure that logging for Azure KeyVault is Enabled'
  impact 1.0
  tag cis: 'azure:5.1.7'
  tag level: 1
  desc <<-DESC
    Enable AuditEvent logging for Key Vault instances to ensure interactions with key vaults
    are logged and available.

    Monitoring how and when your key vaults are accessed, and by whom enables an audit trail
    of interactions with your secrets, keys and certificates managed by Azure Keyvault. You
    can do this by enabling logging for Key Vault, which saves information in an Azure storage
    account that you provide. This creates a new container named insights-logs- auditevent
    automatically for your specified storage account, and you can use this same storage account
    for collecting logs for multiple key vaults.
  DESC

  resource_groups.each do |resource_group|
    azurerm_key_vaults(resource_group: resource_group).names.each do |vault_name|
      describe azurerm_key_vault(resource_group: resource_group, vault_name: vault_name) do
        its('diagnostic_settings')  { should_not be_nil }
        its('diagnostic_settings')  { should_not be_empty }
      end

      azurerm_key_vault(resource_group: resource_group, vault_name: vault_name).diagnostic_settings.each do |setting|
        describe setting do
          its('properties.storageAccountId') { should_not be_nil }
        end

        setting.properties.logs.each do |log|
          describe log do
            its('category')                 { should cmp 'AuditEvent' }
            its('retentionPolicy.days')     { should cmp >= 0 }
          end
        end
      end
    end
  end
end
