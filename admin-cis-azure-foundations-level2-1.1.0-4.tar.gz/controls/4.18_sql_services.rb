# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.18' do
  title "Ensure server parameter 'log_retention_days' is set to 'ON' for PostgreSQL Database Server"
  impact 1.0
  tag cis: 'azure:4.18'
  tag level: 1
  desc <<-DESC
    Enable log_retention_days on PostgreSQL Servers.

    Enabling log_retention_days helps PostgreSQL Database to Sets number of days a log file is
    retained which in turn generates query and error logs. Query and error logs can be used to identify,
    troubleshoot, and repair configuration errors and sub-optimal performance.
  DESC

  resource_groups.each do |resource_group|
    azurerm_postgresql_servers(resource_group: resource_group).names.each do |server_name|
      describe azurerm_postgresql_server(resource_group: resource_group, server_name: server_name) do
        its('configurations') { is_expected.to respond_to(:log_retention_days) }
        its('configurations.log_retention_days.properties.value') { should cmp > 3 }
      end
    end
  end
end
