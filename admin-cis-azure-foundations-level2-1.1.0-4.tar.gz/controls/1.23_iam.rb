# frozen_string_literal: true

title 'Identity and Access Management'

control '1.23' do
  title 'Ensure that no custom subscription owner roles are created'
  impact 1.0
  tag cis: 'azure:1.23'
  tag level: 2
  desc <<-DESC
    Do not create custom roles with subscription ownership. It is recommended to use the principle
    of least privilege, assigning only needed privileges instead of allowing full administrative access.

    Classic subscription admin roles offer basic access management and include Account Administrator,
    Service Administrator, and Co-Administrators. It is recommended, to begin with, the least necessary
    permission, and add permissions as needed by the account holder. This ensures the account holder
    cannot perform actions which were not intended.
  DESC

  custom_owners = azurerm_role_definitions.entries
                      .select { |r| r.properties.type == 'CustomRole' &&
                                    r.properties.assignableScopes.include?('/') &&
                                    r.properties.permissions.any? { |perm| perm.actions.include?('*') }}
                      .map(&:name)
  if custom_owners.empty?
    describe custom_owners do
      it { should be_empty }
    end
  else
    custom_owners.each do |role|
      describe azurerm_role_definition(name: role) do
        it { should_not exist }
      end
    end
  end
end
