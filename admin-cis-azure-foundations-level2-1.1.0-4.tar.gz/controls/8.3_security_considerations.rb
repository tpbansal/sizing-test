# frozen_string_literal: true
locked_resources = attribute('locked_resources', value: {})

title 'Other Security Considerations'

control '8.3' do
  title 'Ensure that Resource Locks are set for mission critical Azure resources'
  impact 1.0
  tag cis: 'azure:8.3'
  tag level: 2
  desc <<-DESC
    Resource Manager Locks provide a way for administrators to lock down Azure resources to prevent
    deletion or changing of a resource. These locks sit outside of the Role Based Access
    Controls (RBAC) hierarchy and, when applied, will place restrictions on the resource for
    all users. These are very useful when you have an important resource in your subscription
    that users should not be able to delete or change and can help prevent accidental
    and malicious changes or deletion.
  DESC

  only_if('No Locked Resources defined.') { locked_resources.any? }

  locked_resources.each do |lock|
    if lock['lock_level']
      # Ensure the correct type of lock is applied, if supplied.
      describe azurerm_locks(resource_group: lock['resource_group'],
                             resource_name: lock['resource_name'],
                             resource_type: lock['resource_type']).entries.map { |l| l.properties.level } do
        it { should_not be_empty }
        it { should include lock['lock_level'] }
      end
    else
      # Otherwise simply assert a lock exists.
      describe azurerm_locks(resource_group: lock['resource_group'],
                             resource_name: lock['resource_name'],
                             resource_type: lock['resource_type']) do
        it { should exist }
      end
    end
  end
end
