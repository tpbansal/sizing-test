# frozen_string_literal: true

title 'App Service'

control '9.5' do
  title 'Ensure that Register with Azure Active Directory is enabled on App Service'
  impact 1.0
  tag cis: 'azure:9.5'
  tag level: 1
  desc <<-DESC
    Managed service identity in App Service makes the app more secure by eliminating secrets from the app,
    such as credentials in the connection strings. When registering with Azure Active Directory in the app service,
    the app will connect to other Azure services securely without the need of username and passwords.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_webapps(resource_group: resource_group).names.each do |webapp|
      describe azurerm_webapp(resource_group: resource_group, name: webapp) do
        it { should have_identity }
        its('identity.principalId') { should_not be_nil }
      end
    end
  end
end
