# frozen_string_literal: true

title 'Security Center'

control '2.4' do
  title "Ensure ASC Default policy setting 'Monitor OS Vulnerabilities' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.4'
  tag level: 1
  desc <<-DESC
    Enable OS vulnerabilities recommendations for virtual machines.

    Rationale: When this setting is enabled, it analyzes operating system
    configurations daily to determine issues that could make the virtual machine
    vulnerable to attack. The policy also recommends configuration changes to
    address these vulnerabilities.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:systemConfigurationsMonitoringEffect) }
    its('default_policy.properties.parameters.systemConfigurationsMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
