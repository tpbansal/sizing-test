# frozen_string_literal: true

title 'App Service'

control '9.3' do
  title 'Ensure web app is using the latest version of TLS encryption'
  impact 1.0
  tag cis: 'azure:9.3'
  tag level: 1
  desc <<-DESC
    The TLS(Transport Layer Security) protocol secures transmission of data over the internet using
    standard encryption technology. Encryption should be set with the latest version of TLS.
    App service allows TLS 1.2 by default, which is the recommended TLS level by industry standards, such as PCI DSS.

    App service currently allows the web app to set TLS versions 1.0, 1.1 and 1.2.
    It is highly recommended to use the latest TLS 1.2 version for web app secure connections.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_webapps(resource_group: resource_group).names.each do |webapp|
      describe azurerm_webapp(resource_group: resource_group, name: webapp) do
        its('configuration.properties.minTlsVersion') { should cmp >= 1.2 }
      end
    end
  end
end
