# frozen_string_literal: true

title 'Identity and Access Management'

control '1.11' do
  title "Ensure that 'Users can register applications' is set to 'No'"
  impact 1.0
  tag cis: 'azure:1.11'
  tag level: 2
  desc <<-DESC
    Require administrators to register third-party applications.

    It is recommended to let administrator register custom-developed applications.
    This ensures that the application undergoes a security review before exposing active directory data to it.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to User settings
    4. Ensure that Users can register applications is set to No'
  end
end
