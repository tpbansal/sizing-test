# frozen_string_literal: true

title 'App Service'

control '9.4' do
  title 'Ensure the web app has Client Certificates (Incoming client certificates) set to On'
  impact 1.0
  tag cis: 'azure:9.4'
  tag level: 1
  desc <<-DESC
    Client certificates allow for the app to request a certificate for incoming requests.
    Only clients that have a valid certificate will be able to reach the app.

    The TLS mutual authentication technique in enterprise environments ensures the
    authenticity of clients to the server. If incoming client certificates are enabled, then only an
    authenticated client who has valid certificates can access the app.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_webapps(resource_group: resource_group).names.each do |webapp|
      describe azurerm_webapp(resource_group: resource_group, name: webapp) do
        its('properties') { should have_attributes(clientCertEnabled: true) }
      end
    end
  end
end
