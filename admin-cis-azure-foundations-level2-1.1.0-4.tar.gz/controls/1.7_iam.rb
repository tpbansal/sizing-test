# frozen_string_literal: true

title 'Identity and Access Management'

control '1.7' do
  title "Ensure that 'Notify users on password resets?' is set to 'Yes'"
  impact 1.0
  tag cis: 'azure:1.7'
  tag level: 1
  desc <<-DESC
    Ensure that the users are notified on their primary and secondary emails on
    password resets.

    Rationale: User notification on password reset is a passive way of confirming
    password reset activity. It helps the user to recognize unauthorized password
    reset activities.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:

    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to Password reset
    4. Go to Notification
    5. Ensure that Notify users on password resets? is set to Yes'
  end
end
