# frozen_string_literal: true

title 'Other Security Considerations'

control '8.5' do
  title 'Enable role-based access control (RBAC) within Azure Kubernetes Services'
  impact 1.0
  tag cis: 'azure:8.5'
  tag level: 1
  desc <<-DESC
    Ensure that RBAC is enabled on all Azure Kubernetes Services Instances

    Azure Kubernetes Services has the capability to integrate Azure Active Directory
    users and groups into Kubernetes RBAC controls within the AKS Kubernetes API Server.
    This should be utilized to enable granular access to Kubernetes resources within the AKS
    clusters supporting RBAC controls not just of the overarching AKS instance but also the
    individual resources managed within Kubernetes.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_aks_clusters(resource_group: resource_group).names.each do |cluster|
      describe azurerm_aks_cluster(resource_group: resource_group, name: cluster) do
        its('properties')            { is_expected.to respond_to(:enableRBAC) }
        its('properties.enableRBAC') { should be true }
      end
    end
  end
end
