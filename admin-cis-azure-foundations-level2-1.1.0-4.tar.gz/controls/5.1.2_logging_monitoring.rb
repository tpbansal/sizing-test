# frozen_string_literal: true

title 'Logging and Monitoring'

control '5.1.2' do
  title 'Ensure that Activity Log Retention is set 365 days or greater'
  impact 1.0
  tag cis: 'azure:5.1.2'
  tag level: 1
  desc <<-DESC
    Ensure Activity Log Retention is set for 365 days or greater

    A Log Profile controls how your Activity Log is exported and retained. Since the average
    time to detect a breach is 210 days, it is recommended to retain your activity log for 365 days
    or more in order to have time to respond to any incidents.

    NOTE:
    Setting the Retention (days) to 0 from portal retains the data forever. 
    Setting Retention (days) to 0 from portal sets days to 0 and enabled to false.
  DESC

  profiles = azurerm_monitor_log_profiles
  describe profiles do
    its('names') { should_not be_empty }
  end

  profiles.names.each do |profile_name|
    profile = azurerm_monitor_log_profile(name: profile_name)
    if profile.retention_enabled
      describe profile do
        its('retention_days') { should be >= 365 }
      end
    else
      describe profile do
        its('retention_days') { should be 0 }
      end
    end
  end
end
