# frozen_string_literal: true

title 'Identity and Access Management'

control '1.14' do
  title "Ensure that 'Guests can invite' is set to 'No'"
  impact 1.0
  tag cis: 'azure:1.14'
  tag level: 2
  desc <<-DESC
    Restrict guest invitations.

    Restricting invitation through administrators ensures
    that only authorized accounts have access to cloud resources.
    This helps to maintain 'Need to Know' and inadvertent access to data.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to User settings
    4. Go to External Users
    5. Ensure that Guests can invite is set to No'
  end
end
