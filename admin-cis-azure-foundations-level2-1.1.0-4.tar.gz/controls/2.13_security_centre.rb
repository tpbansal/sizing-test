# frozen_string_literal: true

title 'Security Center'

control '2.13' do
  title "Ensure ASC Default policy setting 'Monitor Adaptive Application Whitelisting' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.13'
  tag level: 1
  desc <<-DESC
    Enable adaptive application controls.

    Rationale: Adaptive application controls help control which applications can
    run on your VMs located in Azure, which among other benefits helps harden
    your VMs against malware. Security Center uses machine learning to analyze
    the processes running in the VM and helps you apply whitelisting rules using
    this intelligence.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:adaptiveApplicationControlsMonitoringEffect) }
    its('default_policy.properties.parameters.adaptiveApplicationControlsMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
