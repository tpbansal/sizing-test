# frozen_string_literal: true

title 'Other Security Considerations'

control '8.1' do
  title 'Ensure that the expiration date is set on all keys'
  impact 1.0
  tag cis: 'azure:8.1'
  tag level: 1
  desc <<-DESC
    Ensure that all keys in Azure Key Vault have an expiration time set.

    Azure Key Vault enables users to store and use cryptographic keys within
    the Microsoft Azure environment. The exp (expiration time) attribute identifies
    the expiration time on or after which the key MUST NOT be used for a cryptographic
    operation. By default, keys never expire. It is thus recommended that keys be
    rotated in the key vault and set an explicit expiration time for all keys.
    This ensures that the keys cannot be used beyond their assigned lifetimes.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_key_vaults(resource_group: resource_group).names.each do |vault_name|
      azurerm_key_vault_keys(vault_name).entries.each do |key|
        describe key do
          its('kid')            { should_not be_nil }
          its('attributes')     { is_expected.to respond_to(:exp) }
          its('attributes.exp') { should_not be_nil }
        end
      end
    end
  end
end
