# frozen_string_literal: true

title 'App Service'

php_apps = []
azurerm_resource_groups.names.each do |resource_group|
  azurerm_webapps(resource_group: resource_group).names.each do |app_name|
    app = azurerm_webapp(resource_group: resource_group, name: app_name)
    php_apps << app unless app.stack_version('php').nil?
  end
end

control '9.7' do
  title 'Ensure that PHP version is the latest, if used to run the web app'
  impact 1.0
  tag cis: 'azure:9.7'
  tag level: 1
  desc <<-DESC
    Periodically newer versions are released for PHP software either due to security flaws or to include additional
    functionality. Using the latest PHP version for web apps is recommended in order to take advantage
    of security fixes, if any, and/or additional functionalities of the newer version.
  DESC

  # Skip if no PHP apps are found.
  only_if('No PHP Apps found.') { !php_apps.empty? }
  php_apps.each do |php_app|
    describe php_app do
      it { should be_using_latest('php') }
    end
  end
end
