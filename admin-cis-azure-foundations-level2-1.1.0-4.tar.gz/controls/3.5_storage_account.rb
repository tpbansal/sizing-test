# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Storage Accounts'

control '3.5' do
  title 'Ensure that shared access signature tokens are allowed only over https'
  impact 1.0
  tag cis: 'azure:3.5'
  tag level: 1
  desc <<-DESC
    Shared access signature tokens should be allowed only over https protocol.

    A shared access signature (SAS) is a URI that grants restricted access rights to Azure Storage
    resources. You can provide a shared access signature to clients who should not be trusted with
    your storage account key but whom you wish to delegate access to certain storage account
    resources. By distributing a shared access signature URI to these clients, you grant them access
    to a resource for a specified period of time.
    It is recommended to allow such access requests over https protocol only.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:

    On the Azure Console:

    1. Go to Storage Accounts
    2. For each storage account, go to Shared access signature
    3. Set Allowed protocols to HTTPS only'
  end
end
