# frozen_string_literal: true

title 'App Service'

control '9.10' do
  title 'Ensure that HTTP version is the latest, if used to run the web app'
  impact 1.0
  tag cis: 'azure:9.10'
  tag level: 1
  desc <<-DESC
    Periodically, newer versions are released for HTTP either due to security flaws or to include
    additional functionality. Using the latest HTTP version for web apps to take advantage of
    security fixes, if any, and/or new functionalities of the newer version.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_webapps(resource_group: resource_group).names.each do |webapp|
      describe azurerm_webapp(resource_group: resource_group, name: webapp) do
        its('configuration.properties') { should have_attributes(http20Enabled: true) }
      end
    end
  end
end
