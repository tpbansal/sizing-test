# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Storage Accounts'

control '3.8' do
  title "Ensure 'Trusted Microsoft Services' is enabled for Storage Account access"
  impact 1.0
  tag cis: 'azure:3.8'
  tag level: 2
  desc <<-DESC
    Turning on firewall rules for storage account will block access to incoming requests for data,
    including from other Azure services. This includes using the Portal, writing logs, etc.
    We can re-enable functionality. The customer can get access to services like Monitor,
    Networking, Hubs, and Event Grid by enabling "Trusted Microsoft Services" through exceptions.
    Also, Backup and Restore of Virtual Machines using unmanaged disks in storage accounts
    with network rules applied is supported via creating an exception.
  DESC

  resource_groups.each do |resource_group|
    azurerm_storage_accounts(resource_group: resource_group).names.each do |storage_account_name|
      describe azurerm_storage_account(resource_group: resource_group, name: storage_account_name) do
        its('properties.networkAcls.bypass') { should include 'AzureServices' }
      end
    end
  end
end
