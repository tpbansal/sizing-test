# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.13' do
  title "Ensure 'Enforce SSL connection' is set to 'ENABLED' for PostgreSQL Database Server"
  impact 1.0
  tag cis: 'azure:4.13'
  tag level: 1
  desc <<-DESC
    Enable SSL connection on PostgreSQL Servers.

    SSL connectivity helps to provide a new layer of security, by connecting
    database server to client applications using Secure Sockets Layer (SSL).
    Enforcing SSL connections between database server and client applications
    helps protect against "man in the middle" attacks by encrypting the data
    stream between the server and application.
  DESC

  resource_groups.each do |resource_group|
    azurerm_postgresql_servers(resource_group: resource_group).names.each do |server|
      describe azurerm_postgresql_server(resource_group: resource_group, server_name: server) do
        its('properties.sslEnforcement') { should eq 'Enabled' }
      end
    end
  end
end
