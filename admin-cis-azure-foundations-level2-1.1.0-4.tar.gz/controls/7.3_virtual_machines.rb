# frozen_string_literal: true

title 'Virtual Machines'

control '7.3' do
  title "Ensure that 'Unattached disks' are encrypted"
  impact 1.0
  tag cis: 'azure:7.3'
  tag level: 1
  desc <<-DESC
    Ensure that unattached disks in a subscription are encrypted.

    Encrypting the IaaS VM's disks ensures that its entire content is fully unrecoverable without
    a key and thus protects the volume from unwarranted reads. Even if the disk is not attached to
    any of the VMs, there is always a risk where a compromised user account with administrative
    access to VM service can mount/attach these data disks which may lead to sensitive information
    disclosure and tampering.
  DESC

  azurerm_virtual_machine_disks.where { attached == false }.entries.each do |disk|
    describe azurerm_virtual_machine_disk(resource_group: disk.resource_group, name: disk.name) do
      its('encryption_enabled') { should be true }
    end
  end
end
