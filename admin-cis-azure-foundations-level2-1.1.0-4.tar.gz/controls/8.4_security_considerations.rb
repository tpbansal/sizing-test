# frozen_string_literal: true

title 'Other Security Considerations'

control '8.4' do
  title 'Ensure the key vault is recoverable'
  impact 1.0
  tag cis: 'azure:8.4'
  tag level: 1
  desc <<-DESC
    The key vault contains object keys, secrets and certificates.
    Accidental unavailability of a key vault can cause immediate data loss
    or loss of security functions (authentication, validation, verification, non-repudiation, etc.)
    supported by the key vault objects.

    It is recommended the key vault be made recoverable by enabling the "Do Not Purge" and
    "Soft Delete" functions. This is in order to prevent loss of encrypted data including
    storage accounts, SQL databases, and/or dependent services provided by key vault objects
    (Keys, Secrets, Certificates) etc., as may happen in the case of accidental deletion by a
    user or from disruptive activity by a malicious user.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_key_vaults(resource_group: resource_group).names.each do |vault_name|
      describe azurerm_key_vault(resource_group: resource_group, vault_name: vault_name) do
        its('properties')                       { is_expected.to respond_to(:enablePurgeProtection) }
        its('properties.enablePurgeProtection') { should be true }
        its('properties')                       { is_expected.to respond_to(:enableSoftDelete) }
        its('properties.enableSoftDelete')      { should be true }
      end
    end
  end
end
