# frozen_string_literal: true

title 'Logging and Monitoring'

control '5.1.6' do
  title 'Ensure the storage account containing the container with activity logs is encrypted with BYOK (Use Your Own Key)'
  impact 1.0
  tag cis: 'azure:5.1.6'
  tag level: 2
  desc <<-DESC
    The storage account with the activity log export container is configured to use BYOK (Use Your Own Key).

    Configuring the storage account with the activity log export container to use BYOK (Use Your Own Key)
    provides additional confidentiality controls on log data as a given user must have read permission on the
    corresponding storage account and must be granted decrypt permission by the CMK.
  DESC

  profiles = azurerm_monitor_log_profiles
  describe profiles do
    its('names') { should_not be_empty }
  end

  profiles.names.each do |name|
    sa = azurerm_monitor_log_profile({ name: name }).storage_account
    describe azurerm_storage_account(resource_group: sa[:resource_group], name: sa[:name]) do
      its('properties.encryption.keySource') { should cmp 'Microsoft.Keyvault' }
      its('properties.encryption') { is_expected.to respond_to(:keyvaultproperties) }
      its('properties.encryption.keyvaultproperties') { should_not be_nil }
    end
  end
end
