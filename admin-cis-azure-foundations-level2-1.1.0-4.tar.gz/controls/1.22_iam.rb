# frozen_string_literal: true

title 'Identity and Access Management'

control '1.22' do
  title "Ensure that 'Require Multi-Factor Auth to join devices' is set to 'Yes'"
  impact 1.0
  tag cis: 'azure:1.22'
  tag level: 1
  desc <<-DESC
    Joining devices to the active directory should require Multi-factor authentication.
    Multi-factor authentication is recommended when adding devices to Azure AD. When set
    to Yes users that are adding devices from the internet must first use the second method
    of authentication before their device is successfully added to the directory. This ensures
    that rogue devices are not added to the directory for a compromised user account.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:
    1. Go to Azure Active Directory
    2. Go to Devices
    3. Go to Device settings
    4. Ensure that Require Multi-Factor Auth to join devices is set to Yes'
  end
end
