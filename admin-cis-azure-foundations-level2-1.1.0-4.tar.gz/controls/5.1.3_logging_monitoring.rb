# frozen_string_literal: true

title 'Logging and Monitoring'

control '5.1.3' do
  title 'Ensure audit profile captures all the activities'
  impact 1.0
  tag cis: 'azure:5.1.3'
  tag level: 1
  desc <<-DESC
    The log profile should be configured to export all activities from the control/management plane.

    A log profile controls how the activity log is exported. Configuring the log profile to
    collect logs for the categories "write", "delete" and "action" ensures that all the
    control/management plane activities performed on the subscription are exported.
  DESC

  profiles = azurerm_monitor_log_profiles
  describe profiles do
    its('names') { should_not be_empty }
  end

  profiles.names.each do |profile|
    describe azurerm_monitor_log_profile(name: profile) do
      its('properties.categories') { should include 'Write' }
      its('properties.categories') { should include 'Delete' }
      its('properties.categories') { should include 'Action' }
    end
  end
end
