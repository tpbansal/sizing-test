# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Virtual Machines'

control '7.1' do
  title "Ensure that 'OS disk' are encrypted"
  impact 1.0
  tag cis: 'azure:7.1'
  tag level: 1
  desc <<-DESC
    Encrypting your IaaS VM's OS disk (boot volume) ensures that its entire
    content is fully unrecoverable without a key and thus protects the volume
    from unwarranted reads.
  DESC

  resource_groups.each do |resource_group|
    azurerm_virtual_machines(resource_group: resource_group).os_disks.each do |os_disk|
      describe azurerm_virtual_machine_disk(resource_group: resource_group, name: os_disk) do
        its('encryption_enabled') { should be true }
      end
    end
  end
end
