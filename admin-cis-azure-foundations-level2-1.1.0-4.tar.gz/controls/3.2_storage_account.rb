# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Storage Accounts'

control '3.2' do
  title 'Ensure that storage account access keys are periodically regenerated'
  impact 1.0
  tag cis: 'azure:3.2'
  tag level: 1
  desc <<-DESC
    Regenerate storage account access keys periodically.

    When you create a storage account, Azure generates two 512-bit storage access keys,
    which are used for authentication when the storage account is accessed. Rotating
    these keys periodically ensures that any inadvertent access or exposure does not
    result in these keys being compromised.
  DESC

  resource_groups.each do |resource_group|
    azurerm_storage_accounts(resource_group: resource_group).names.each do |storage_account_name|
      describe azurerm_storage_account(resource_group: resource_group, name: storage_account_name) do
        it { should have_recently_generated_access_key }
      end
    end
  end
end
