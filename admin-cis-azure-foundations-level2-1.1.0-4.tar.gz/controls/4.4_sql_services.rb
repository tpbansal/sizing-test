# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.4' do
  title "Ensure that 'Advanced Data Security' on a SQL server is set to 'On'"
  impact 1.0
  tag cis: 'azure:4.4'
  tag level: 2
  desc <<-DESC
    SQL Server "Advanced Data Security" provides a new layer of security,
    which enables customers to detect and respond to potential threats as they
    occur by providing security alerts on anomalous activities. Users will receive
    an alert upon suspicious database activities, potential vulnerabilities,
    and SQL injection attacks, as well as anomalous database access patterns.

    SQL Server Threat Detection alerts provide details of suspicious activity
    and recommend action on how to investigate and mitigate the threat.
    Additionally, SQL server Advanced Data Security includes functionality for
    discovering and classifying sensitive data.

    Advanced Data Security is a paid feature.
    It is recommended to enable the feature at least on business-critical SQL Servers.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name) do
        its('threat_detection_settings.properties') { should have_attributes(state: 'Enabled') }
      end
    end
  end
end
