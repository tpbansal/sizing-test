# frozen_string_literal: true

title 'App Service'

control '9.2' do
  title 'Ensure web app redirects all HTTP traffic to HTTPS in Azure App Service'
  impact 1.0
  tag cis: 'azure:9.2'
  tag level: 1
  desc <<-DESC
    Azure Web Apps allows sites to run under both HTTP and HTTPS by default.
    Web apps can be accessed by anyone using non-secure HTTP links by default.
    Non-secure HTTP requests can be restricted and all HTTP requests redirected to the secure HTTPS port.
    It is recommended to enforce HTTPS-only traffic.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_webapps(resource_group: resource_group).names.each do |webapp|
      describe azurerm_webapp(resource_group: resource_group, name: webapp) do
        its('properties') { should have_attributes(httpsOnly: true) }
      end
    end
  end
end
