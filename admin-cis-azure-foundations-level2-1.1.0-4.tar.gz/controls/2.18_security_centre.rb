# frozen_string_literal: true

title 'Security Center'

control '2.18' do
  title "Ensure that 'Send me emails about alerts' is set to 'On'"
  impact 1.0
  tag cis: 'azure:2.18'
  tag level: 1
  desc <<-DESC
    Enable security alerts emailing to security contact.

    Rationale: Enabling security alerts emailing ensures that you receive the
    security alert emails from Microsoft. This ensures that you are aware of any
    potential security issues and you can timely mitigate the risk.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('notifications_enabled') { should be true }
  end
end
