# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Virtual Machines'

control '7.2' do
  title "Ensure that 'Data disks' are encrypted"
  impact 1.0
  tag cis: 'azure:7.2'
  tag level: 1
  desc <<-DESC
    Encrypting your IaaS VM's Data disks (non-boot volume) ensures that its
    entire content is fully unrecoverable without a key and thus protects the
    volume from unwarranted reads.
  DESC

  resource_groups.each do |resource_group|
    azurerm_virtual_machines(resource_group: resource_group).data_disks.each do |names|
      names.each do |disk|
        describe azurerm_virtual_machine_disk(resource_group: resource_group, name: disk) do
          its('encryption_enabled') { should be true }
        end
      end
    end
  end
end
