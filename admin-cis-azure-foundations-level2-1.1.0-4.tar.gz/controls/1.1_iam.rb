# frozen_string_literal: true

title 'Identity and Access Management'

control '1.1' do
  title 'Ensure that multi-factor authentication is enabled for all privileged users'
  impact 1.0
  tag cis: 'azure:1.1'
  tag level: 1
  desc <<-DESC
    Enable multi-factor authentication for all user credentials who have write
    access to Azure resources. These include roles like

    * Service Co-Administrators
    * Subscription Owners
    * Contributors

    Rationale: Multi-factor authentication requires an individual to present a
    minimum of two separate forms of authentication before access is granted.
    Multi-factor authentication provides additional assurance that the individual
    attempting to gain access is who they claim to be. With multi-factor
    authentication, an attacker would need to compromise at least two different
    authentication mechanisms, increasing the difficulty of compromise and thus
    reducing the risk.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:

    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to All Users
    4. Click on Multi-Factor Authentication button on the top bar
    5. Ensure that MULTI-FACTOR AUTH STATUS is Enabled for all users who are Service Co-Administrators OR Owners OR Contributors.'
  end
end
