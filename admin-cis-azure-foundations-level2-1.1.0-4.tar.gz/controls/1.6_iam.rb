# frozen_string_literal: true

title 'Identity and Access Management'

control '1.6' do
  title "Ensure that 'Number of days before users are asked to re-confirm their authentication information' is not set to '0'"
  impact 1.0
  tag cis: 'azure:1.6'
  tag level: 1
  desc <<-DESC
    Ensure that the number of days before users are asked to re-confirm their
    authentication information is not set to 0.

    Rationale: If authentication re-confirmation is disabled, registered users will
    never be prompted to re- confirm their existing authentication information. If
    the authentication information for a user, such as a phone number or email
    changes, then the password reset information for that user goes to the
    previously registered authentication information.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:

    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to Password reset
    4. Go to Registration
    5. Ensure that Number of days before users are asked to re-confirm their authentication information is not set to 0'
  end
end
