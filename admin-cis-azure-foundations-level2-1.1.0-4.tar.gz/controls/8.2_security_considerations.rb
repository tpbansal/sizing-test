# frozen_string_literal: true

title 'Other Security Considerations'

control '8.2' do
  title 'Ensure that the expiration date is set on all Secrets'
  impact 1.0
  tag cis: 'azure:8.2'
  tag level: 1
  desc <<-DESC
    Ensure that all Secrets in Azure Key Vault have an expiry time set.

    Azure Key Vault enables users to store and secrets within the Microsoft
    Azure environment. Secrets in Azure Key Vault are octet sequences with a
    maximum size of 25k bytes each. The exp (expiration time) attribute identifies
    the expiration time on or after which the secret MUST NOT be used. By default,
    Secrets never expire. It is thus recommended that you rotate your secrets in
    the key vault and set an explicit expiry time for all secrets. This ensures that
    the secrets cannot be used beyond their assigned lifetimes.
  DESC

  azurerm_resource_groups.names.each do |resource_group|
    azurerm_key_vaults(resource_group: resource_group).names.each do |vault_name|
      azurerm_key_vault_secrets(vault_name).entries.each do |secret|
        describe secret do
          it                    { should_not be_nil }
          its('id')             { should_not be_nil }
          its('attributes')     { is_expected.to respond_to(:exp) }
          its('attributes.exp') { should_not be_nil }
        end
      end
    end
  end
end
