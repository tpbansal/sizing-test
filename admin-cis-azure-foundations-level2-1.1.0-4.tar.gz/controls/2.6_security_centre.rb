# frozen_string_literal: true

title 'Security Center'

control '2.6' do
  title "Ensure ASC Default policy setting 'Monitor Disk Encryption' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.6'
  tag level: 1
  desc <<-DESC
    Enable Disk encryption recommendations for virtual machines.

    Rationale: When this setting is enabled, it recommends enabling disk
    encryption in all virtual machines to enhance data protection at rest.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:diskEncryptionMonitoringEffect) }
    its('default_policy.properties.parameters.diskEncryptionMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
