resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)
nsg = attribute('network_watcher_network_security_group', value: nil)

title 'Networking'

control '6.4' do
  title 'Ensure that Network Security Group Flow Log retention period is greater than 90 days'
  impact 1.0
  tag cis: 'azure:6.4'
  tag level: 2
  desc <<-DESC
    Network Security Group Flow Logs should be enabled and retention period
    is set to greater than or equal to 90 days.

    Flow logs enable capturing information about IP traffic flowing in and out
    of your Network Security Groups. Logs can be used to check for anomalies and
    give insight into suspected breaches.
  DESC

  only_if('`network_watcher_network_security_group` must be provided as an Input.') { !nsg.nil? }

    # First ensure a NW exists.
    describe azurerm_network_watchers do
      its('names') { should_not be_empty }
    end

  # Then ensure the NW is configured correctly.
  resource_groups.each do |resource_group|
    azurerm_network_watchers(resource_group: resource_group).names.each do |nw_name|
      nw = azurerm_network_watcher(resource_group: resource_group, name: nw_name)
      nw.nsg = nsg
      describe nw do
        its('flow_logs.properties') { is_expected.to respond_to(:retentionPolicy) }
        its('flow_logs.properties.retentionPolicy.enabled') { should be true }
        its('flow_logs.properties.retentionPolicy.days')    { should be >= 90 }
      end
    end
  end
end
