# frozen_string_literal: true

title 'Security Center'

control '2.12' do
  title "Ensure ASC Default policy setting 'Monitor JIT Network Access' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.12'
  tag level: 2
  desc <<-DESC
    Enable JIT Network Access for virtual machines.

    Rationale: When this setting is enabled, it Security Center locks down
    inbound traffic to your Azure VMs by creating an NSG rule. You select the
    ports on the VM to which inbound traffic should be locked down. Just in time
    virtual machine (VM) access can be used to lock down inbound traffic to your
    Azure VMs, reducing exposure to attacks while providing easy access to
    connect to VMs when needed.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:jitNetworkAccessMonitoringEffect) }
    its('default_policy.properties.parameters.jitNetworkAccessMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
