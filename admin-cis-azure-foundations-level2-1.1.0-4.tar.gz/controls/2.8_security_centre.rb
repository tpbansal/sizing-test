# frozen_string_literal: true

title 'Security Center'

control '2.8' do
  title " Ensure ASC Default policy setting 'Monitor Web Application Firewall' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.8'
  tag level: 1
  desc <<-DESC
    Enable Web application firewall recommendations for virtual machines.

    Rationale: When this setting is enabled, it recommends that a web application
    firewall is provisioned on virtual machines when either of the following is
    true:
      * Instance-level public IP (ILPIP) is used and the inbound security rules for
        the associated network security group are configured to allow access to port
        80/443.
      * Load-balanced IP is used and the associated load
        balancing and inbound network address translation (NAT) rules are configured
        to allow access to port 80/443.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:webApplicationFirewallMonitoringEffect) }
    its('default_policy.properties.parameters.webApplicationFirewallMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
