# frozen_string_literal: true

title 'Logging and Monitoring'
control '5.2.7' do
  title 'Ensure that Activity Log Alert exists for Delete Security Solution'
  impact 1.0
  tag cis: 'azure:5.2.7'
  tag level: 1
  desc <<-DESC
    Create an activity log alert for the Delete Security Solution event.

    Monitoring for Delete Security Solution events gives insight into changes to the
    active security solutions and may reduce the time it takes to detect suspicious activity.
  DESC

  required_scope = "/subscriptions/#{azurerm_subscription.id}"

  alerts = azurerm_monitor_activity_log_alerts
           .where { operations.include?('Microsoft.Security/securitySolutions/delete') }
           .where { location.include?('Global') }

  describe alerts do
    its('entries') { should_not be_empty }
  end

  describe.one do
    alerts.entries.each do |a|
      alert  = azurerm_monitor_activity_log_alert(resource_group: a.resource_group, name: a.name)
      # Scope can either have a trailing slash or not and be compliant.
      describe alert do
        it            { should exist }
        it            { should be_enabled }
        its('scopes') { should include required_scope}
      end
      describe alert do
        it            { should exist }
        it            { should be_enabled }
        its('scopes') { should include required_scope+"/"}
      end
    end
  end
end
