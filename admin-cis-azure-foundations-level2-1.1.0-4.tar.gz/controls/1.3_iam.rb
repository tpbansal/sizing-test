# frozen_string_literal: true

title 'Identity and Access Management'

control '1.3' do
  title 'Ensure that there are no guest users'
  impact 1.0
  tag cis: 'azure:1.3'
  tag level: 1
  desc <<-DESC
    Do not add guest users if not needed.

    Rationale: Azure AD is extended to include Azure AD B2B collaboration,
    allowing you to invite people from outside your organization to be guest
    users in your cloud account. Until you have a business need to provide guest
    access to any user, avoid creating such guest users. Guest users are
    typically added out of your employee on-boarding/off-boarding process and
    could potentially be lying there unnoticed indefinitely leading to a
    potential vulnerability.
  DESC

  describe azurerm_ad_users(filter: "userType eq 'Guest'") do
    its('guest_accounts') { should eq [] }
  end
end
