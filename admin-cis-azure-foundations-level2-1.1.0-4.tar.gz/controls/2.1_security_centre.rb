# frozen_string_literal: true

title 'Security Center'

control '2.1' do
  title 'Ensure that standard pricing tier is selected (Scored)'
  impact 1.0
  tag cis: 'azure:2.1'
  tag level: 2
  desc <<-DESC
    Standard pricing tier enables threat detection for networks and virtual machines,
    providing threat intelligence, anomaly detection, and behavior analytics in Azure
    Security Center.

    Rationale: Enabling the Standard pricing tier allows for further defense in depth,
    with threat detection provided by the Microsoft Security Response Center (MSRC).
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('pricing_tier') { should eq('Standard') }
  end
end
