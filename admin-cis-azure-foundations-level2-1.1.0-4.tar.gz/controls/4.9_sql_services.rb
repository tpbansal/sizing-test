# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.9' do
  title "Ensure that 'Data encryption' is set to 'On'"
  impact 1.0
  tag cis: 'azure:4.9'
  tag level: 1
  desc <<-DESC
    Azure SQL Database transparent data encryption helps protect against the threat of malicious activity
    by performing real-time encryption and decryption of the database, associated backups, and transaction
    log files at rest without requiring changes to the application.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      azurerm_sql_databases(resource_group: resource_group, server_name: sql_server_name).names.each do |sql_database_name|
        next unless sql_database_name != 'master' # master DB is excluded https://docs.microsoft.com/en-gb/azure/sql-database/transparent-data-encryption-azure-sql?view=sql-server-2017
        describe azurerm_sql_database(resource_group: resource_group, server_name: sql_server_name, database_name: sql_database_name) do
          its('encryption_settings.properties') { should have_attributes(status: 'Enabled') }
        end
      end
    end
  end
end
