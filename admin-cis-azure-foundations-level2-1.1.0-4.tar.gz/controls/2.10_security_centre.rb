# frozen_string_literal: true

title 'Security Center'

control '2.10' do
  title "Ensure ASC Default policy setting 'Monitor Vulnerability Assessment' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.10'
  tag level: 1
  desc <<-DESC
    Enable Vulnerability assessment recommendations for virtual machines.

    Rationale: When this setting is enabled, it recommends that you install a
    vulnerability assessment solution on your VM.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:vulnerabilityAssesmentMonitoringEffect) }
    its('default_policy.properties.parameters.vulnerabilityAssesmentMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
