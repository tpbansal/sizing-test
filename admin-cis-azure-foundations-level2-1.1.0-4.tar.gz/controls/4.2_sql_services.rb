# frozen_string_literal: true

resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'SQL Services'

control '4.2' do
  title "Ensure that 'AuditActionGroups' in 'auditing' policy for a SQL server is set properly"
  impact 1.0
  tag cis: 'azure:4.2'
  tag level: 1
  desc <<-DESC
    To capture all critical activities done on SQL Servers and databases within sql servers,
    auditing should be configured to capture appropriate 'AuditActionGroups'.

    Property AuditActionGroup should contains at least SUCCESSFUL_DATABASE_AUTHENTICATION_GROUP,
    FAILED_DATABASE_AUTHENTICATION_GROUP, BATCH_COMPLETED_GROUP to ensure comprehensive audit
    logging for SQL servers and SQL databases hosted on SQL Server.
  DESC

  resource_groups.each do |resource_group|
    azurerm_sql_servers(resource_group: resource_group).names.each do |sql_server_name|
      describe azurerm_sql_server(resource_group: resource_group, server_name: sql_server_name) do
        its('auditing_settings.properties') { is_expected.to respond_to(:auditActionsAndGroups) }
        its('auditing_settings.properties.auditActionsAndGroups') { should include 'SUCCESSFUL_DATABASE_AUTHENTICATION_GROUP' }
        its('auditing_settings.properties.auditActionsAndGroups') { should include 'FAILED_DATABASE_AUTHENTICATION_GROUP' }
        its('auditing_settings.properties.auditActionsAndGroups') { should include 'BATCH_COMPLETED_GROUP' }
      end
    end
  end
end
