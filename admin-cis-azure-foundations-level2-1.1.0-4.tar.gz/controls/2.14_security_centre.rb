# frozen_string_literal: true

title 'Security Center'

control '2.14' do
  title "Ensure ASC Default policy setting 'Monitor SQL Auditing' is not 'Disabled'"
  impact 1.0
  tag cis: 'azure:2.14'
  tag level: 1
  desc <<-DESC
    Enable SQL auditing recommendations.

    Rationale: When this setting is enabled, it recommends that access
    auditing for the Azure Database be enabled for compliance, advanced
    threat detection, and for investigation purposes.
  DESC

  describe azurerm_security_center_policy(name: 'default') do
    its('default_policy.properties.parameters') { is_expected.to respond_to(:sqlAuditingMonitoringEffect) }
    its('default_policy.properties.parameters.sqlAuditingMonitoringEffect.value') { should_not eq 'Disabled' }
  end
end
