# frozen_string_literal: true

title 'Security Center'

control '2.2' do
  title "Ensure that 'Automatic provisioning of monitoring agent' is set to 'On'"
  impact 1.0
  tag cis: 'azure:2.2'
  tag level: 1
  desc <<-DESC
    Enable Automatic provisioning of monitoring agent to collect security data.

    Rationale: When Automatic provisioning of monitoring agent is turned on, Azure Security
    Center provisions the Microsoft Monitoring Agent on all existing supported
    Azure virtual machines and any new ones that are created. The Microsoft
    Monitoring agent scans for various security-related configurations and events
    such as system updates, OS vulnerabilities, and endpoint protection and
    provides alerts.
  DESC

  describe azurerm_security_center_policy do
    it { should have_auto_provisioning_enabled }
  end
end
