# frozen_string_literal: true

title 'Identity and Access Management'

control '1.10' do
  title "Ensure that 'Users can add gallery apps to their Access Panel' is set to 'No'"
  impact 1.0
  tag cis: 'azure:1.10'
  tag level: 2
  desc <<-DESC
    Require administrators to provide consent for the apps before use.

    Until you are running Azure Active Directory as an identity provider
    for third-party applications, do not allow users to use the identity outside
    of your cloud environment. User's profile information contains private
    information such as phone number and email address which could then be sold
    off to other third parties without requiring any further consent from the user.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Users
    3. Go to User Settings
    4. Go to Manage how end users launch and view their applications
    5. Ensure that Users can add gallery apps to their Access Panel is set to No'
  end
end
