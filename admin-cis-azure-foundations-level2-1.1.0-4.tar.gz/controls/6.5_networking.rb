# frozen_string_literal: true
resource_groups = attribute('provided_resource_group', value: azurerm_resource_groups.names)

title 'Networking'

control '6.5' do
  title 'Ensure that Network Watcher is "Enabled"'
  impact 1.0
  tag cis: 'azure:6.5'
  tag level: 1
  desc <<-DESC
    Enable Network Watcher for your Azure Subscriptions.

    Rationale: Network diagnostic and visualization tools available with Network
    Watcher help you understand, diagnose, and gain insights to your network in Azure.
  DESC

  locations = %w{westus eastus northeurope westeurope eastasia southeastasia northcentralus southcentralus centralus
                 eastus2 japaneast japanwest brazilsouth australiaeast australiasoutheast centralindia southindia
                 westindia canadacentral canadaeast westcentralus westus2 ukwest uksouth koreacentral koreasouth
                 francecentral australiacentral southafricanorth uaenorth}

  # First ensure at least one NW exists.
  describe azurerm_network_watchers do
    its('names') { should_not be_empty }
  end

  # Then ensure one is enabled for each region supported.
  resource_groups.each do |resource_group|
    azurerm_network_watchers(resource_group: resource_group).names.each do |nw_name|
      nw = azurerm_network_watcher(resource_group: resource_group, name: nw_name)
      locations.delete(nw.location)
      describe nw do
        its('provisioning_state') { should eq 'Succeeded' }
      end
    end
  end

  # Finally, after checking all NWs in all RGs, there should be no values left in the locations array.
  describe locations do
    it { is_expected.to be_empty, -> { "Network Watcher was expected to be enabled in all supported regions, but was not enabled in: #{locations}" } }
  end
end
