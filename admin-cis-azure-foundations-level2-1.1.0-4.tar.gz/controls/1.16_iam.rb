# frozen_string_literal: true

title 'Identity and Access Management'

control '1.16' do
  title "Ensure that 'Self-service group management enabled' is set to 'No'"
  impact 1.0
  tag cis: 'azure:1.16'
  tag level: 2
  desc <<-DESC
    Restrict group creation to administrators only.

    Self-service group management enables users to create and manage security
    groups or Office 365 groups in Azure Active Directory (Azure AD).
    Until your business requires this day-to-day delegation to some users,
    it is good to disable self-service group management.
  DESC

  describe 'no API support' do
    skip 'No Azure API support. Alternative Audit Procedure:
    On the Azure Console:

    1. Go to Azure Active Directory
    2. Go to Groups
    3. Go to General Settings
    4. Ensure Restrict access to Groups in the Access Panel is set to Yes'
  end
end
