# Azure CIS Foundations Benchmark 1.1.0 Level 2

This profile implements the [CIS Azure Foundations Benchmark](https://azure.microsoft.com/en-us/resources/cis-microsoft-azure-foundations-security-benchmark/en-us/) in [InSpec](https://www.inspec.io/) and leverages the [InSpec Azure Resource Pack](https://github.com/inspec/inspec-azure).

