# frozen_string_literal: true

title 'Ensure MFA is enabled for the "root" account'

control 'cis-aws-benchmark-iam-1.13' do
  impact 1.0
  title 'Ensure MFA is enabled for the "root" account'
  desc '
  The root account is the most privileged user in an AWS account. MFA adds an extra layer of protection on top of a
  user name and password. With MFA enabled, when a user signs in to an AWS website, they will be prompted for their
  user name and password as well as for an authentication code from their AWS MFA device.
  '
  tag cis: 'aws:1.13'
  tag level: 1

  describe aws_iam_root_user do
    it { should have_mfa_enabled }
  end
end
