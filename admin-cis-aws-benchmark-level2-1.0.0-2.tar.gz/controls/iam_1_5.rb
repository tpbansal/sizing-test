# frozen_string_literal: true

title 'Ensure IAM password policy requires at least one uppercase letter'

control 'cis-aws-benchmark-iam-1.5' do
  impact 1.0
  title 'Ensure IAM password policy requires at least one uppercase letter'
  desc '
  Password policies are, in part, used to enforce password complexity requirements. IAM password policies can be
  used to ensure password are comprised of different character sets. It is recommended that the password policy
  require at least one uppercase letter.
  '
  tag cis: 'aws:1.5'
  tag level: 1

  describe aws_iam_password_policy do
    it { should require_uppercase_characters }
  end
end
