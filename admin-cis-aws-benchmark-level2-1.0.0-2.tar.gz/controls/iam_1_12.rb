# frozen_string_literal: true

title 'Ensure no root account access key exists'

control 'cis-aws-benchmark-iam-1.12' do
  impact 1.0
  title 'Ensure no root account access key exists'
  desc '
  The root account is the most privileged user in an AWS account. AWS Access Keys provide programmatic access to a
  given AWS account. It is recommended that all access keys associated with the root account be removed.
  '
  tag cis: 'aws:1.12'
  tag level: 1

  describe aws_iam_root_user do
    it { should_not have_access_key }
  end
end
