# frozen_string_literal: true

title 'Do not setup access keys during initial user setup for all IAM users that have a console password'

control 'cis-aws-benchmark-iam-1.21' do
  impact 1.0
  title 'Do not setup access keys during initial user setup for all IAM users that have a console password '
  desc '
  AWS console defaults the checkbox for creating access keys to enabled. This results in many access keys being
  generated unnecessarily. In addition to unnecessary credentials, it also generates unnecessary management
  work in auditing and rotating these keys.
  '
  tag cis: 'aws:1.21'
  tag level: 1

  describe aws_iam_access_keys.where { never_used }.where { created_with_user } do
    it { should_not exist }
  end
end
