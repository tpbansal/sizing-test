# frozen_string_literal: true

title 'Ensure access keys are rotated every 90 days or less'

control 'cis-aws-benchmark-iam-1.4' do
  impact 1.0
  title 'Ensure access keys are rotated every 90 days or less'
  desc '
  Access keys consist of an access key ID and secret access key, which are used to sign programmatic requests that
  you make to AWS. AWS users need their own access keys to make programmatic calls to AWS from the AWS Command Line
  Interface (AWS CLI), Tools for Windows PowerShell, the AWS SDKs, or direct HTTP calls using the APIs for individual
  AWS services. It is recommended that all access keys be regularly rotated.
  '
  tag cis: 'aws:1.4'
  tag level: 1

  describe aws_iam_access_keys.where { created_days_ago > 90 }.where { active } do
    it { should_not exist }
  end
end
