# frozen_string_literal: true

title 'Ensure IAM password policy prevents password reuse'

control 'cis-aws-benchmark-iam-1.10' do
  impact 1.0
  title 'Ensure IAM password policy prevents password reuse'
  desc '
  IAM password policies can prevent the reuse of a given password by the same user. It is recommended that the
  password policy prevent the reuse of passwords.
  '
  tag cis: 'aws:1.10'
  tag level: 1

  describe aws_iam_password_policy do
    it { should prevent_password_reuse }
  end
end
