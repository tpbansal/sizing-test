# frozen_string_literal: true

title 'Ensure CloudTrail is enabled in all regions'

control 'cis-aws-benchmark-logging-2.1' do
  impact 1.0
  title 'Ensure CloudTrail is enabled in all regions'
  desc '
  AWS CloudTrail is a web service that records AWS API calls for your account and delivers log files to  you. The
  recorded information includes the identity of the API caller, the time of the API call, the source IP address of the
  API caller, the request parameters, and the response elements returned by the AWS service. CloudTrail provides a
  history of AWS API calls for an account, including API calls made via the Management Console, SDKs, command line
  tools, and higher-level AWS services (such as CloudFormation).
  '
  tag cis: 'aws:2.1'
  tag level: 1

  describe.one do
    aws_cloudtrail_trails.trail_arns.each do |trail_arn|
      describe aws_cloudtrail_trail(trail_arn) do
        it { should be_multi_region_trail }
        it { should be_logging }
        it { should have_event_selector_mgmt_events_rw_type_all }
      end
    end
  end
end
