# frozen_string_literal: true

title 'Ensure rotation for customer created CMKs is enabled'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-logging-2.8' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure rotation for customer created CMKs is enabled'
  desc '
  AWS Key Management Service (KMS) allows customers to rotate the backing key which is key material stored within
  the KMS which is tied to the key ID of the Customer Created customer master key (CMK). It is the backing key that is
  used to perform cryptographic operations such as encryption and decryption. Automated key rotation currently retains
  all prior backing keys so that decryption of encrypted data can take place transparently. It is recommended that
  CMK key rotation be enabled.
  '
  tag cis: 'aws:2.8'
  tag level: 2

  aws_regions.region_names.each do |region|
    aws_kms_keys(aws_region: region).key_ids.each do |key_id|
      key = aws_kms_key(aws_region: region, key_id: key_id)
      next if key.managed_by_aws?
      next if !key.enabled?

      describe key do
        it { should have_rotation_enabled }
      end
    end
  end
end
