# frozen_string_literal: true

title 'Ensure CloudTrail logs are encrypted at rest using KMS CMKs'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-logging-2.7' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure CloudTrail logs are encrypted at rest using KMS CMKs'
  desc '
  AWS CloudTrail is a web service that records AWS API calls for an account and makes those logs available to users
  and resources in accordance with IAM policies. AWS Key Management Service (KMS) is a managed service that helps
  create and control the encryption keys used to encrypt account data, and uses Hardware Security Modules (HSMs) to
  protect the security of encryption keys. CloudTrail logs can be configured to leverage server side encryption (SSE)
  and KMS customer created master keys (CMK) to further protect CloudTrail logs. It is recommended that CloudTrail be
  configured to use SSE-KMS.
  '
  tag cis: 'aws:2.7'
  tag level: 2

  aws_cloudtrail_trails.trail_arns.each do |trail_arn|
    describe aws_cloudtrail_trail(trail_arn) do
      it { should be_encrypted }
    end
  end
end
