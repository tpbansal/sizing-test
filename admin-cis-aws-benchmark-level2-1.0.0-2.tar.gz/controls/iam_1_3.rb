# frozen_string_literal: true

title 'Ensure credentials unused for 90 days or greater are disabled'

control 'cis-aws-benchmark-iam-1.3' do
  impact 1.0
  title 'Ensure credentials unused for 90 days or greater are disabled'
  desc '
  AWS IAM users can access AWS resources using different types of credentials, such as passwords or access keys. It
  is recommended that all credentials that have been unused in 90 or greater days be removed or deactivated.
  '
  tag cis: 'aws:1.3'
  tag level: 1

  # Active, used-at-least-once stale keys
  describe aws_iam_access_keys
    .where { ever_used }
    .where { last_used_days_ago > 90 }
    .where { active } do
    it { should_not exist }
  end

  # No long-unused passwords
  describe aws_iam_users
    .where { password_ever_used? }
    .where { password_last_used_days_ago > 90 } do
    it { should_not exist }
  end
end
