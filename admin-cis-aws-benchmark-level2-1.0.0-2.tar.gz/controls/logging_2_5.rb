# frozen_string_literal: true

title 'Ensure AWS Config is enabled in all regions'

control 'cis-aws-benchmark-logging-2.5' do
  impact 1.0
  title 'Ensure AWS Config is enabled in all regions'
  desc '
  AWS Config is a web service that performs configuration management of supported AWS resources within your account
  and delivers log files to you. The recorded information includes the configuration item (AWS resource),
  relationships between configuration items (AWS resources), any configuration changes between resources. It is
  recommended to enable AWS Config in all regions.
  '
  tag cis: 'aws:2.5'
  tag level: 1

  aws_region_names = aws_regions.region_names

  describe.one do
    aws_region_names.each do |region|
      describe aws_config_recorder(aws_region: region) do
        it { should be_recording_all_global_types }
      end
    end
  end

  aws_region_names.each do |region|
    describe aws_config_recorder(aws_region: region) do
      it { should exist }
      it { should be_recording }
      it { should be_recording_all_resource_types }
    end

    describe aws_config_delivery_channel(aws_region: region) do
      it { should exist }
      its('s3_bucket_name') { should_not be_empty }
      its('sns_topic_arn') { should_not be_empty }
    end
  end
end
