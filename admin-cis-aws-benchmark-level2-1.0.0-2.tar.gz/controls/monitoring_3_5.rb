# frozen_string_literal: true

title 'Ensure a log metric filter and alarm exist for CloudTrail configuration changes'

control 'cis-aws-benchmark-monitoring-3.5' do
  impact 1.0
  title 'Ensure a log metric filter and alarm exist for CloudTrail configuration changes'
  desc '
  Real-time monitoring of API calls can be achieved by directing CloudTrail Logs to CloudWatch Logs and establishing
  corresponding metric filters and alarms. It is recommended that a metric filter and alarm be established for
  detecting changes to CloudTrail\'s configurations.
  '
  tag cis: 'aws:3.5'
  tag level: 1

  log_metric_filter_pattern = '{ ($.eventName = CreateTrail) || ($.eventName = UpdateTrail) || ($.eventName = DeleteTrail) || ($.eventName = StartLogging) || ($.eventName = StopLogging) }'
  log_group_candidates = []

  aws_cloudtrail_trails.trail_arns.each do |trail_arn|
    log_group = aws_cloudtrail_trail(trail_arn).get_log_group_for_multi_region_active_mgmt_rw_all
    log_group_candidates += [log_group] if !log_group.nil?
  end

  describe.one do
    log_group_candidates.each do |log_group|
      describe aws_cloudwatch_log_metric_filter(log_group_name: log_group, pattern: log_metric_filter_pattern) do
        it { should exist }
      end
    end
  end

  describe.one do
    log_group_candidates.each do |log_group|
      log_metric_filter = aws_cloudwatch_log_metric_filter(log_group_name: log_group, pattern: log_metric_filter_pattern)
      next if !log_metric_filter.exists?

      describe aws_cloudwatch_alarm(metric_name: log_metric_filter.metric_name, metric_namespace: log_metric_filter.metric_namespace) do
        it { should exist }
        its('alarm_actions') { should_not be_empty }
      end
    end
  end

  describe.one do
    log_group_candidates.each do |log_group|
      log_metric_filter = aws_cloudwatch_log_metric_filter(log_group_name: log_group, pattern: log_metric_filter_pattern)
      next if !log_metric_filter.exists?

      cloud_watch_alarm = aws_cloudwatch_alarm(metric_name: log_metric_filter.metric_name, metric_namespace: log_metric_filter.metric_namespace)
      next if !cloud_watch_alarm.exists?

      describe aws_sns_topic(cloud_watch_alarm.alarm_actions.first) do
        it { should exist }
        its('confirmed_subscription_count') { should_not be_zero }
      end
    end
  end
end
