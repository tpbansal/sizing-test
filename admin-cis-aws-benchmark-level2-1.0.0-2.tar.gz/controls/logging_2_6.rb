# frozen_string_literal: true

title 'Ensure S3 bucket access logging is enabled on the CloudTrail S3 bucket'

control 'cis-aws-benchmark-logging-2.6' do
  impact 1.0
  title 'Ensure S3 bucket access logging is enabled on the CloudTrail S3 bucket'
  desc '
  S3 Bucket Access Logging generates a log that contains access records for each request made to your S3 bucket. An
  access log record contains details about the request, such as the request type, the resources specified in the
  request worked, and the time and date the request was processed. It is recommended that bucket access logging be
  enabled on the CloudTrail S3 bucket.
  '
  tag cis: 'aws:2.6'
  tag level: 1

  aws_cloudtrail_trails.trail_arns.each do |trail_arn|
    bucket_name = aws_cloudtrail_trail(trail_arn).s3_bucket_name
    describe aws_s3_bucket(bucket_name) do
      it { should have_access_logging_enabled }
    end
  end
end
