# frozen_string_literal: true

title 'Ensure the default security group of every VPC restricts all traffic'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-networking-4.4' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure the default security group of every VPC restricts all traffic'
  desc '
  Once a VPC peering connection is established, routing tables must be updated to establish any connections between
  the peered VPCs. These routes can be as specific as desired - even peering a VPC to only a single host on the
  other side of the connection.

  Rationale:
  Being highly selective in peering routing tables is a very effective way of minimizing the impact of breach as
  resources outside of these routes are inaccessible to the peered VPC.
  '
  tag cis: 'aws:4.4'
  tag level: 2

  describe 'cis-aws-benchmark-networking-4.4' do
    skip '
    Audit:
    Review routing tables of peered VPCs for whether they route all subnets of each VPC and whether that is necessary
    to accomplish the intended purposes for peering the VPCs.
    1. List all the route tables from a VPC and check if "GatewayId" is pointing to a <peering_connection_id>
       (e.g. pcx-1a2b3c4d) and if "DestinationCidrBlock" is as specific as desired.
    Via CLI:
       aws ec2 describe-route-tables --filter "Name=vpc-id,Values=<vpc_id>"
                                     --query "RouteTables[*].{RouteTableId:RouteTableId, VpcId:VpcId,
                                                            Routes:Routes, AssociatedSubnets:Associations[*].SubnetId}"
  '
  end
end
