# frozen_string_literal: true

title 'Ensure hardware MFA is enabled for the "root" account'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-iam-1.14' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure hardware MFA is enabled for the "root" account'
  desc '
  The root account is the most privileged user in an AWS account. MFA adds an extra layer of protection on top of
  a user name and password. With MFA enabled, when a user signs in to an AWS website, they will be prompted for
  their user name and password as well as for an authentication code from their AWS MFA device. For Level 2, it is
  recommended that the root account be protected with a hardware MFA.
  '
  tag cis: 'aws:1.14'
  tag level: 2

  describe aws_iam_root_user do
    it { should have_hardware_mfa_enabled }
  end
end
