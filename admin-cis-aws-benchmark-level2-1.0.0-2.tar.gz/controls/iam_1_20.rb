# frozen_string_literal: true

title 'Ensure a support role has been created to manage incidents with AWS Support'

control 'cis-aws-benchmark-iam-1.20' do
  impact 1.0
  title 'Ensure a support role has been created to manage incidents with AWS Support'
  desc '
  AWS provides a support center that can be used for incident notification and response, as well as technical
  support and customer services. Create an IAM Role to allow authorized users to manage incidents with AWS Support.
  '
  tag cis: 'aws:1.20'
  tag level: 1

  describe aws_iam_policy(policy_name: 'AWSSupportAccess') do
    its('attachment_count') { should_not be_zero }
  end
end
