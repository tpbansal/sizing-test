# frozen_string_literal: true

title 'Ensure IAM policies that allow full "*:*" administrative privileges are not created'

control 'cis-aws-benchmark-iam-1.22' do
  impact 1.0
  title 'Ensure IAM policies that allow full "*:*" administrative privileges are not created'
  desc '
  IAM policies are the means by which privileges are granted to users, groups, or roles. It is recommended and
  considered a standard security advice to grant least privilege that is, granting only the permissions required
  to perform a task. Determine what users need to do and then craft policies for them that let the users perform
  only those tasks, instead of allowing full administrative privileges.
  '
  tag cis: 'aws:1.22'
  tag level: 1

  # Customer-managed Policy Check
  aws_iam_policies.where { arn.split(':')[4] != 'aws' }.policy_names.each do |iam_policy_name|
    describe aws_iam_policy(policy_name: iam_policy_name) do
      it { should_not have_statement('Effect' => 'Allow', 'Resource' => '*', 'Action' => '*') }
    end
  end

  # AWS-managed policy check
  describe aws_iam_policy(policy_name: 'AdministratorAccess') do
    its('attached_users') { should be_empty }
    its('attached_groups') { should be_empty }
    its('attached_roles') { should be_empty }
  end
end
