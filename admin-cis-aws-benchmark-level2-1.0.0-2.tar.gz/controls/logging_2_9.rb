# frozen_string_literal: true

title 'Ensure VPC flow logging is enabled in all VPCs'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-logging-2.9' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure VPC flow logging is enabled in all VPCs'
  desc '
  VPC Flow Logs is a feature that enables you to capture information about the IP traffic going to and from network
  interfaces in your VPC. After you\'ve created a flow log, you can view and retrieve its data in Amazon CloudWatch
  Logs. It is recommended that VPC Flow Logs be enabled for packet "Rejects" for VPCs.
  '
  tag cis: 'aws:2.9'
  tag level: 2

  aws_regions.region_names.each do |region|
    aws_vpcs(aws_region: region).vpc_ids.each do |vpc|
      describe aws_flow_log(aws_region: region, vpc_id: vpc) do
        it { should exist }
        it { should be_attached_to_vpc }
      end
    end
  end
end
