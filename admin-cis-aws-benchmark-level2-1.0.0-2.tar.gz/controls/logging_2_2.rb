# frozen_string_literal: true

title 'Ensure CloudTrail log file validation is enabled'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-logging-2.2' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure CloudTrail log file validation is enabled'
  desc '
  CloudTrail log file validation creates a digitally signed digest file containing a hash of each log that CloudTrail
  writes to S3. These digest files can be used to determine whether a log file was changed, deleted, or unchanged after
  CloudTrail delivered the log. It is recommended that file validation be enabled on all CloudTrails.
  '
  tag cis: 'aws:2.2'
  tag level: 2

  aws_cloudtrail_trails.trail_arns.each do |trail_arn|
    describe aws_cloudtrail_trail(trail_arn) do
      it { should have_log_file_validation_enabled }
    end
  end
end
