# frozen_string_literal: true

title 'Avoid the use of the "root" account'

control 'cis-aws-benchmark-iam-1.1' do
  impact 1.0
  title 'Avoid the use of the "root" account'
  desc '
  The "root" account has unrestricted access to all resources in the AWS account. It is highly recommended that the
  use of this account be avoided.

  Rationale:
  The "root" account is the most privileged AWS account. Minimizing the use of this account and adopting the principle
  of least privilege for access management will reduce the risk of accidental changes and unintended disclosure of
  highly privileged credentials.
  '
  tag cis: 'aws:1.1'
  tag level: 1

  describe 'cis-aws-benchmark-iam-1.1' do
    skip '
    Audit:
    Implement the Ensure a log metric filter and alarm exist for usage of "root" account recommendation in the
    Monitoring section of this benchmark to receive notifications of root account usage. Additionally, executing the
    following commands will provide ad-hoc means for determining the last time the root account was used:
      > aws iam generate-credential-report
      > aws iam get-credential-report --query \'Content\' --output text | base64 -d | cut -d, -f1,5,11,16 | grep -B1 \'<root_account>\'
    Note: there are a few conditions under which the use of the root account is required, such as requesting a
    penetration test or creating a CloudFront private key.
  '
  end
end
