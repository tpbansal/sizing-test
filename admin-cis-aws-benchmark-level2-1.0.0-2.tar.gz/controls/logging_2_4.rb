# frozen_string_literal: true

title 'Ensure CloudTrail trails are integrated with CloudWatch Logs'

control 'cis-aws-benchmark-logging-2.4' do
  impact 1.0
  title 'Ensure CloudTrail trails are integrated with CloudWatch Logs'
  desc '
  AWS CloudTrail is a web service that records AWS API calls made in a given AWS account. The recorded information
  includes the identity of the API caller, the time of the API call, the source IP address of the API caller, the
  request parameters, and the response elements returned by the AWS service. CloudTrail uses Amazon S3 for log file
  storage and delivery, so log files are stored durably. In addition to capturing CloudTrail logs within a specified
  S3 bucket for long term analysis, realtime analysis can be performed by configuring CloudTrail to send logs to
  CloudWatch Logs. For a trail that is enabled in all regions in an account, CloudTrail sends log files from all those
  regions to a CloudWatch Logs log group. It is recommended that CloudTrail logs be sent to CloudWatch Logs.

  Note: The intent of this recommendation is to ensure AWS account activity is being captured, monitored, and
  appropriately alarmed on. CloudWatch Logs is a native way to accomplish this using AWS services but does not
  preclude the use of an alternate solution.
  '
  tag cis: 'aws:2.4'
  tag level: 1

  aws_cloudtrail_trails.trail_arns.each do |trail_arn|
    describe aws_cloudtrail_trail(trail_arn) do
      its('delivered_logs_days_ago') { should eq 0 }
      its('cloud_watch_logs_role_arn') { should match(/arn:aws/) }
    end
  end
end
