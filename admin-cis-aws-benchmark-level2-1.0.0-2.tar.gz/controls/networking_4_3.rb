# frozen_string_literal: true

title ' Ensure the default security group of every VPC restricts all traffic'

cis_level = attribute('cis_level')

control 'cis-aws-benchmark-networking-4.3' do
  only_if { cis_level == 2 }
  impact 1.0
  title ' Ensure the default security group of every VPC restricts all traffic'
  desc '
  A VPC comes with a default security group whose initial settings deny all inbound traffic, allow all outbound
  traffic, and allow all traffic between instances assigned to the security group. If you don\'t specify a security
  group when you launch an instance, the instance is automatically assigned to this default security group. Security
  groups provide stateful filtering of ingress/egress network traffic to AWS resources. It is recommended that the
  default security group restrict all traffic.

  The default VPC in every region should have its default security group updated to comply. Any newly created VPCs
  will automatically contain a default security group that will need remediation to comply with this recommendation.
  '
  tag cis: 'aws:4.3'
  tag level: 2

  aws_regions.region_names.each do |region|
    aws_vpcs(aws_region: region).vpc_ids.each do |vpc|
      describe aws_security_group(aws_region: region, vpc_id: vpc, group_name: 'default') do
        it { should_not allow_in }
      end
    end
  end
end
