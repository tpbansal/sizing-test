# frozen_string_literal: true

title 'Ensure the S3 bucket used to store CloudTrail logs is not publicly accessible'

control 'cis-aws-benchmark-logging-2.3' do
  impact 1.0
  title 'Ensure the S3 bucket used to store CloudTrail logs is not publicly accessible'
  desc '
  CloudTrail logs a record of every API call made in your AWS account. These logs file are stored in an S3 bucket. It
  is recommended that the bucket policy, or access control list (ACL), applied to the S3 bucket that CloudTrail logs
  to prevents public access to the CloudTrail logs.
  '
  tag cis: 'aws:2.3'
  tag level: 1

  aws_cloudtrail_trails.trail_arns.each do |trail_arn|
    bucket_name = aws_cloudtrail_trail(trail_arn).s3_bucket_name
    describe aws_s3_bucket(bucket_name) do
      it { should exist }
      it { should_not be_public }
    end
  end
end
