# frozen_string_literal: true

title 'Ensure no security groups allow ingress from 0.0.0.0/0 to port 3389'

control 'cis-aws-benchmark-networking-4.2' do
  impact 1.0
  title 'Ensure no security groups allow ingress from 0.0.0.0/0 to port 3389'
  desc '
  Security groups provide stateful filtering of ingress/egress network traffic to AWS resources. It is recommended
  that no security group allows unrestricted ingress access to port 3389.
  '
  tag cis: 'aws:4.2'
  tag level: 1

  aws_regions.region_names.each do |region|
    aws_security_groups(aws_region: region).group_ids.each do |security_group_id|
      describe aws_security_group(aws_region: region, group_id: security_group_id) do
        it { should_not allow_in(ipv4_range: '0.0.0.0/0', port: 3389) }
      end
    end
  end
end
