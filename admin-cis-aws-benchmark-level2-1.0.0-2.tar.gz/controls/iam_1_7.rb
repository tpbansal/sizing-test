# frozen_string_literal: true

title 'Ensure IAM password policy require at least one symbol'

control 'cis-aws-benchmark-iam-1.7' do
  impact 1.0
  title 'Ensure IAM password policy require at least one symbol'
  desc '
  Password policies are, in part, used to enforce password complexity requirements. IAM password policies can be
  used to ensure password are comprised of different character sets. It is recommended that the password policy
  require at least one symbol.
  '
  tag cis: 'aws:1.7'
  tag level: 1

  describe aws_iam_password_policy do
    it { should require_symbols }
  end
end
