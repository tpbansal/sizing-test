# frozen_string_literal: true

title 'Ensure multi-factor authentication (MFA) is enabled for all IAM users that have a console password'

control 'cis-aws-benchmark-iam-1.2' do
  impact 1.0
  title 'Ensure multi-factor authentication (MFA) is enabled for all IAM users that have a console password'
  desc '
  Multi-Factor Authentication (MFA) adds an extra layer of protection on top of a user name and password. With MFA
  enabled, when a user signs in to an AWS website, they will be prompted for their user name and password as well
  as for an authentication code from their AWS MFA device. It is recommended that MFA be enabled for all accounts
  that have a console password.
  '
  tag cis: 'aws:1.2'
  tag level: 1

  describe aws_iam_users.where(has_console_password: true).where(has_mfa_enabled: false) do
    it { should_not exist }
  end
end
