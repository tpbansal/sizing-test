# frozen_string_literal: true

title 'Ensure IAM password policy requires minimum length of 14 or greater'

control 'cis-aws-benchmark-iam-1.9' do
  impact 1.0
  title 'Ensure IAM password policy requires minimum length of 14 or greater'
  desc '
  Password policies are, in part, used to enforce password complexity requirements. IAM password policies can be
  used to ensure password are at least a given length. It is recommended that the password policy require a
  minimum password length of 14 characters.
  '
  tag cis: 'aws:1.9'
  tag level: 1

  describe aws_iam_password_policy do
    its('minimum_password_length') { should be >= 14 }
  end
end
