# frozen_string_literal: true

title 'Ensure IAM password policy require at least one number'

control 'cis-aws-benchmark-iam-1.8' do
  impact 1.0
  title 'Ensure IAM password policy require at least one number'
  desc '
  Password policies are, in part, used to enforce password complexity requirements. IAM password policies can be
  used to ensure password are comprised of different character sets. It is recommended that the password policy
  require at least one number.
  '
  tag cis: 'aws:1.8'
  tag level: 1

  describe aws_iam_password_policy do
    it { should require_lowercase_characters }
  end
end
