# frozen_string_literal: true

title 'Ensure IAM policies are attached only to groups or roles'

control 'cis-aws-benchmark-iam-1.16' do
  impact 1.0
  title 'Ensure IAM policies are attached only to groups or roles'
  desc '
  By default, IAM users, groups, and roles have no access to AWS resources. IAM policies are the means by which
  privileges are granted to users, groups, or roles. It is recommended that IAM policies be applied directly to
  groups and roles but not users.
  '
  tag cis: 'aws:1.16'
  tag level: 1

  all_users = aws_iam_users

  describe all_users.where(has_inline_policies: true) do
    its('usernames') { should be_empty }
  end

  describe all_users.where(has_attached_policies: true) do
    its('usernames') { should be_empty }
  end
end
