# frozen_string_literal: true

title 'Ensure IAM password policy expires passwords within 90 days or less'

control 'cis-aws-benchmark-iam-1.11' do
  impact 1.0
  title 'Ensure IAM password policy expires passwords within 90 days or less'
  desc '
  IAM password policies can require passwords to be rotated or expired after a given number of days. It is
  recommended that the password policy expire passwords after 90 days or less.
  '
  tag cis: 'aws:1.11'
  tag level: 1

  describe aws_iam_password_policy do
    its('max_password_age_in_days') { should be <= 90 }
  end
end
