# cis-aws-benchmark-level2
InSpec Profile for the AWS CIS Benchmark Level 2 
