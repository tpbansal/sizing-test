# cis-gcp-benchmark-level2
InSpec Profile for the GCP CIS Benchmark Level 2
