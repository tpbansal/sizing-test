# frozen_string_literal: true

title 'Ensure log metric filter and alerts exists for Audit Configuration Changes'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-logging-2.5' do
  impact 1.0
  title 'Ensure log metric filter and alerts exists for Audit Configuration Changes'
  desc '
  Google Cloud Platform services write audit log entries to Admin Activity and Data Access logs to helps answer
  the questions of "who did what, where, and when?" within Google Cloud Platform projects. Cloud Audit logging
  records information includes the identity of the API caller, the time of the API call, the source IP address of
  the API caller, the request parameters, and the response elements returned by the GCP services. Cloud Audit
  logging provides a history of AWS API calls for an account, including API calls made via the Console, SDKs,
  command line tools, and other GCP services.

  Rationale:
  Admin activity and Data access logs produced by Cloud audit logging enables security analysis, resource change
  tracking, and compliance auditing. Configuring metric filter and alerts for Audit Configuration Changes ensures
  recommended state of audit configuration and hence, all the activities in project are audit-able at any
  point in time.
  '
  tag cis: 'gcp:2.5'
  tag level: 1

  filter = "protoPayload.methodName=\"SetIamPolicy\" AND\nprotoPayload.serviceData.policyDelta.auditConfigDeltas:*\n"
  describe google_project_metrics(project: gcp_project_id).where(metric_filter: filter) do
    it { should exist }
  end

  alert_policy_exists = false
  google_project_metrics(project: gcp_project_id).where(metric_filter: filter).metric_types.each do |metric_type|
    metric_filter = "metric.type=\"#{metric_type}\" project=\"#{gcp_project_id}\""
    google_project_alert_policies(project: gcp_project_id).where(policy_enabled_state: true).where { policy_filter_list.include?(metric_filter) }.policy_names.each do |policy_name|
      describe google_project_alert_policy_condition(policy: policy_name, filter: metric_filter) do
        alert_policy_exists=true
        it { should exist }
        its('condition_threshold_value') { should eq 0.001 }
        its('aggregation_alignment_period') { should eq '60s' }
        its('aggregation_cross_series_reducer') { should eq 'REDUCE_COUNT' }
        its('aggregation_per_series_aligner') { should eq 'ALIGN_RATE' }
      end
    end
  end

  describe alert_policy_exists do
    it "Alert policy for filter \"#{filter}\" does not exist" do
      expect(alert_policy_exists).to(be true)
    end
  end
end
