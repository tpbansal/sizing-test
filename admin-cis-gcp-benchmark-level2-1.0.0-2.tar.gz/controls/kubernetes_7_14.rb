# frozen_string_literal: true

title 'Ensure PodSecurityPolicy controller is enabled on the Kubernetes Engine Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.14' do
  impact 1.0
  title 'Ensure PodSecurityPolicy controller is enabled on the Kubernetes Engine Clusters'
  desc '
  A Pod Security Policy is a cluster-level resource that controls security sensitive aspects of the pod
  specification. The PodSecurityPolicy objects define a set of conditions that a pod must run with in order to
  be accepted into the system, as well as defaults for the related fields.

  Rationale:
  The PodSecurityPolicy defines a set of conditions that Pods must meet to be accepted by the cluster; when a request
  to create or update a Pod does not meet the conditions in the PodSecurityPolicy, that request is rejected and an
  error is returned. The PodSecurityPolicy admission controller validates requests against available
  PodSecurityPolicies. PodSecurityPolicies specify a list of restrictions, requirements, and defaults for Pods
  created under the policy.
  '
  tag cis: 'gcp:7.14'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_pod_security_policy_config }
      end
    end
  end
end
