# frozen_string_literal: true

title 'Ensure user-managed/external keys for service accounts are rotated every 90 days or less'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-iam-1.6' do
  impact 1.0
  title 'Ensure user-managed/external keys for service accounts are rotated every 90 days or less.'
  desc '
  Service Account keys consist of a key ID (Private_key_Id) and Private key, which are used to sign programmatic
  requests that you make to Google cloud services accessible to that particular Service account. It is recommended
  that all Service Account keys are regularly rotated.
  '
  tag cis: 'gcp:1.6'
  tag level: 1

  google_service_accounts(project: gcp_project_id).service_account_names.each do |name|
    describe google_service_account_keys(service_account: name).where { valid_after_time < Time.now - 60*60*24*90 } do
      it { should_not exist }
    end
  end
end
