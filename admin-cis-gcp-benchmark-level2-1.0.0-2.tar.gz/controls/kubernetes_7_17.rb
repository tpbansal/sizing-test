# frozen_string_literal: true

title 'Ensure default Service account is not used for Project access in Kubernetes Clusters'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-kubernetes-7.17' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure default Service account is not used for Project access in Kubernetes Clusters'
  desc '
  A service account is an identity that an instance or an application can use to run API requests on your behalf. This
  identity is used to identify applications running on your virtual machine instances to other Google Cloud Platform
  services. By default, Kubernetes Engine nodes are given the Compute Engine default service account. This account
  has broad access by default, making it useful to a wide variety of applications, but it has more permissions than
  are required to run your Kubernetes Engine cluster.

  Rationale:
  You should create and use a minimally privileged service account to run your Kubernetes Engine cluster instead of
  using the Compute Engine default service account. If you are not creating a separate service account for your
  nodes, you should limit the scopes of the node service account to reduce the possibility of a privilege escalation
  in an attack. Kubernetes Engine requires, at a minimum, the service account to have the monitoring.viewer,
  monitoring.metricWriter, and logging.logWriter roles. This ensures that your default service account does not have
  permissions beyond those necessary to run your cluster. While the default scopes are limited, they may include
  scopes beyond the minimally required scopes needed to run your cluster.
  '
  tag cis: 'gcp:7.17'
  tag level: 2

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      google_container_node_pools(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name).node_pool_names.each do |node_pool_name|
        describe google_container_node_pool(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name, nodepool_name: node_pool_name) do
          its('config_service_account') { should_not eq 'default' }
        end
      end
    end
  end
end
