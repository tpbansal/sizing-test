# frozen_string_literal: true

title 'Ensure Private Google Access is set on Kubernetes Engine Cluster Subnets'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.16' do
  impact 1.0
  title 'Ensure Private Google Access is set on Kubernetes Engine Cluster Subnets'
  desc '
  Private Google Access enables your cluster hosts, which have only private IP addresses, to communicate with Google
  APIs and services using an internal IP address rather than an external IP address. External IP addresses are
  routable and reachable over the Internet. Internal (private) IP addresses are internal to Google Cloud Platform
  and are not routable or reachable over the Internet. You can use Private Google Access to allow VMs without Internet
  access to reach Google APIs, services, and properties that are accessible over HTTP/HTTPS.

  Rationale:
  VPC networks and subnetworks provide logically isolated and secure network partitions where you can launch GCP
  resources. When Private Google Access is enabled, VM instances in a subnet can reach the Google Cloud and Developer
  APIs and services without needing an external IP address. Instead, VMs can use their internal IP addresses to access
  Google managed services. Instances with external IP addresses are not affected when you enable the ability to access
  Google services from internal IP addresses. These instances can still connect to Google APIs and managed services.
  '
  tag cis: 'gcp:7.16'
  tag level: 1

  google_compute_regions(project: gcp_project_id).region_names.each do |region_name|
    google_compute_region(project: gcp_project_id, name: region_name).zone_names.each do |zone_name|
      google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_subnetworks.each do |subnetwork_name|
        describe google_compute_subnetwork(project: gcp_project_id, region: region_name, name: subnetwork_name) do
          its('private_ip_google_access') { should be true }
        end
      end
    end
  end
end
