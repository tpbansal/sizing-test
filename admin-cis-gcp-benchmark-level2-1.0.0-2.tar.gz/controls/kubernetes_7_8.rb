# frozen_string_literal: true

title 'Ensure Automatic node upgrades is enabled on Kubernetes Engine Clusters nodes'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.8' do
  impact 1.0
  title 'Ensure Automatic node upgrades is enabled on Kubernetes Engine Clusters nodes'
  desc '
  Node auto-upgrades help you keep the nodes in your cluster or node pool up to date with the latest stable version
  of Kubernetes. Auto-Upgrades use the same update mechanism as manual node upgrades.

  Rationale:
  Node pools with auto-upgrades enabled are automatically scheduled for upgrades when a new stable Kubernetes
  version becomes available. When the upgrade is performed, the node pool is upgraded to match the current cluster
  master version. Some benefits of using enabling auto-upgrades are:
  - Lower management overhead: You don\'t have to manually track and update to the latest version of Kubernetes.
  - Better security: Sometimes new binaries are released to fix a security issue. With auto-upgrades, Kubernetes
    Engine automatically ensures that security updates are applied and kept up to date.
  - Ease of use: Provides a simple way to keep your nodes up to date with the latest Kubernetes features.
  '
  tag cis: 'gcp:7.8'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      google_container_node_pools(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name).node_pool_names.each do |node_pool_name|
        describe google_container_node_pool(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name, nodepool_name: node_pool_name) do
          it { should have_automatic_node_upgrade }
        end
      end
    end
  end
end
