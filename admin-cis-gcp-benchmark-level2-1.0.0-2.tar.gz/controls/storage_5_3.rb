# frozen_string_literal: true

title 'Ensure that logging is enabled for Cloud storage buckets'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-storage-5.3' do
  impact 1.0
  title 'Ensure that logging is enabled for Cloud storage buckets'
  desc '
  Storage Access Logging generates a log that contains access records for each request made to the Storage
  bucket. An access log record contains details about the request, such as the request type, the resources
  specified in the request worked, and the time and date the request was processed. Cloud Storage offers access
  logs and storage logs in the form of CSV files that can be downloaded and used for analysis/incident response.
  Access logs provide information for all of the requests made on a specified bucket and are created hourly, while
  the daily storage logs provide information about the storage consumption of that bucket for the last day. The access
  logs and storage logs are automatically created as new objects in a bucket that you specify. An access log record
  contains details about the request, such as the request type, the resources specified in the request worked, and
  the time and date the request was processed. While storage Logs helps to keep track the amount of data stored in the
  bucket. It is recommended that storage Access Logs and Storage logs are enabled for every Storage Bucket.

  Rationale:
  By enabling access and storage logs on target Storage buckets, it is possible to capture all events which may
  affect objects within target buckets. Configuring logs to be placed in a separate bucket allows access to log
  information which can be useful in security and incident response workflows.

  In most cases, Cloud Audit Logging is the recommended method for generating logs that track API operations
  performed in Cloud Storage:
  - Cloud Audit Logging tracks access on a continuous basis.
  - Cloud Audit Logging produces logs that are easier to work with.
  - Cloud Audit Logging can monitor many of your Google Cloud Platform services, not just Cloud Storage.

  In some cases, you may want to use access & storage logs instead. You most likely want to use access logs if:
  - You want to track access for public objects.
  - You use Access Control Lists (ACLs) to control access to your objects.
  - You want to track changes made by the Object Lifecycle Management feature.
  - You want your logs to include latency information, or the request and response size of individual HTTP requests.

  You most likely want to use storage logs if:
  - You want to track the amount of data stored in your buckets.
  '
  tag cis: 'gcp:5.3'
  tag level: 1

  google_storage_buckets(project: gcp_project_id).bucket_names.each do |bucket_name|
    describe google_storage_bucket(name: bucket_name) do
      it { should have_logging_enabled }
    end
  end
end
