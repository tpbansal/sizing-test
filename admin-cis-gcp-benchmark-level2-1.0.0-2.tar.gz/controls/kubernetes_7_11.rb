# frozen_string_literal: true

title 'Ensure Network policy is enabled on Kubernetes Engine Cluster'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.11' do
  impact 1.0
  title 'Ensure Network policy is enabled on Kubernetes Engine Cluster'
  desc '
  A network policy is a specification of how groups of pods are allowed to communicate with each other and other
  network endpoints. NetworkPolicy resources use labels to select pods and define rules which specify what traffic
  is allowed to the selected pods. The Kubernetes Network Policy API allows the cluster administrator to specify
  what pods are allowed to communicate with each other.

  Rationale:
  By default, pods are non-isolated; they accept traffic from any source. Pods become isolated by having a
  NetworkPolicy that selects them. Once there is any NetworkPolicy in a namespace selecting a particular pod, that
  pod will reject any connections that are not allowed by any NetworkPolicy. (Other pods in the namespace that are
  not selected by any NetworkPolicy will continue to accept all traffic.)
  '
  tag cis: 'gcp:7.11'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_network_policy_enabled }
      end
    end
  end
end
