# frozen_string_literal: true

title 'Ensure that Cloud SQL database instance requires all incoming connections to use SSL'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-database-6.1' do
  impact 1.0
  title 'Ensure that Cloud SQL database instance requires all incoming connections to use SSL'
  desc '
  It is recommended to enforce all incoming connections to SQL database instance to use SSL.

  Rationale:
  SQL database connections if successfully trapped (MITM); can reveal sensitive data like credentials, database
  queries, query outputs etc. For security, it is recommended to always use SSL encryption when connecting to your
  instance. This recommendation is applicable for Postgresql, MySql generation 1 and MySql generation 2 Instances.
  '
  tag cis: 'gcp:6.1'
  tag level: 1

  google_sql_database_instances(project: gcp_project_id).instance_names.each do |instance_name|
    describe google_sql_database_instance(project: gcp_project_id, database: instance_name) do
      it { should have_ip_configuration_require_ssl }
    end
  end
end
