# frozen_string_literal: true

title 'Ensure that Cloud Storage bucket is not anonymously or publicly accessible'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-storage-5.1' do
  impact 1.0
  title 'Ensure that Cloud Storage bucket is not anonymously or publicly accessible'
  desc '
  It is recommended that IAM policy on Cloud Storage bucket does not allows anonymous and/or public access.

  Rationale:
  Allowing anonymous and/or public access grants permissions to anyone to access bucket content. Such access
  might not be desired if you are storing any sensitive data. Hence, ensure that anonymous and/or public access
  to a bucket is not allowed.
  '
  tag cis: 'gcp:5.1'
  tag level: 1

  google_storage_buckets(project: gcp_project_id).bucket_names.each do |bucket_name|
    google_storage_bucket_iam_bindings(bucket: bucket_name).iam_binding_roles.each do |iam_binding_role|
      describe google_storage_bucket_iam_binding(bucket: bucket_name, role: iam_binding_role) do
        its('members') { should_not include 'allUsers' }
        its('members') { should_not include 'allAuthenticatedUsers' }
      end
    end
  end
end
