# frozen_string_literal: true

title 'Ensure Kubernetes Cluster is created with Private cluster enabled'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.15' do
  impact 1.0
  title 'Ensure Kubernetes Cluster is created with Private cluster enabled'
  desc '
  A private cluster is a cluster that makes your master inaccessible from the public internet. In a private cluster,
  nodes do not have public IP addresses, so your workloads run in an environment that is isolated from the
  internet. Nodes have addressed only in the private RFC 1918 address space. Nodes and masters communicate with each
  other privately using VPC peering.

  Rationale:
  With a Private cluster enabled, VPC network peering gives you several advantages over using external IP addresses
  or VPNs to connect networks, including:
  - Network Latency: Public IP networking suffers higher latency than private networking.
  - Network Security: Service owners do not need to have their services exposed to the public Internet and
    deal with its associated risks.
  - Network Cost: GCP charges egress bandwidth pricing for networks using external IPs to communicate even if the
    traffic is within the same zone. If however, the networks are peered they can use internal IPs to communicate and
    save on those egress costs. Regular network pricing still applies to all traffic.
  '
  tag cis: 'gcp:7.15'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should be_a_private_cluster }
      end
    end
  end
end
