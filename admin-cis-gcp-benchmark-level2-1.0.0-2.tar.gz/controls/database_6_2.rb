# frozen_string_literal: true

title 'Ensure that Cloud SQL database Instances are not open to the world'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-database-6.2' do
  impact 1.0
  title 'Ensure that Cloud SQL database Instances are not open to the world'
  desc '
  Database Server should accept connections only from trusted Network(s)/IP(s) and restrict access from the world.

  Rationale:
  To minimize attack surface on a Database server Instance, only trusted/known and required IP(s) should be
  white-listed to connect to it.
  Authorized network should not have IPs/networks configured to 0.0.0.0 or /0 which will allow access to the
  instance from anywhere in the world.
  '
  tag cis: 'gcp:6.2'
  tag level: 1

  google_sql_database_instances(project: gcp_project_id).instance_names.each do |instance_name|
    describe google_sql_database_instance(project: gcp_project_id, database: instance_name) do
      its('authorized_networks') { should_not include '0.0.0.0/0' }
    end
  end
end
