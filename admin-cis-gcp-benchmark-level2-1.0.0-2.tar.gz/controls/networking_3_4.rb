# frozen_string_literal: true

title 'Ensure that RSASHA1 is not used for key-signing key in Cloud DNS DNSSEC'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-networking-3.4' do
  impact 1.0
  title 'Ensure that RSASHA1 is not used for key-signing key in Cloud DNS DNSSEC'
  desc '
  DNSSEC algorithm numbers in this registry may be used in CERT RRs. Zone signing (DNSSEC) and transaction security
  mechanisms (SIG(0) and TSIG) make use of particular subsets of these algorithms. The algorithm used for key signing
  should be recommended one and it should not be weak.

  Rationale:
  DNSSEC algorithm numbers in this registry may be used in CERT RRs. Zonesigning (DNSSEC) and transaction security
  mechanisms (SIG(0) and TSIG) make use of particular subsets of these algorithms.
  The algorithm used for key signing should be recommended one and it should not be weak. When enabling DNSSEC for a
  managed zone, or creating a managed zone with DNSSEC, you can select the DNSSEC signing algorithms and the
  denial-of-existence type. Changing the DNSSEC settings is only effective for a managed zone if DNSSEC is not
  already enabled. If you need to change the settings for a managed zone where it has been enabled, you can turn
  DNSSEC off and then re-enable it with different settings.
  '
  tag cis: 'gcp:3.4'
  tag level: 1

  google_dns_managed_zones(project: gcp_project_id).zone_names.each do |zone_name|
    describe google_dns_managed_zone(project: gcp_project_id, zone: zone_name) do
      its('key_signing_key_algorithm') { should_not eq 'rsasha1' }
    end
  end
end
