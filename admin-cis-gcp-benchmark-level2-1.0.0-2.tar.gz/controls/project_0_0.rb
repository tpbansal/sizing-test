# frozen_string_literal: true

title 'Ensure that the GCP Project exists'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-project-0.0' do
  impact 1.0
  title 'Ensure that the project exists and is in lifecycle state "ACTIVE".'

  describe google_project(project: gcp_project_id) do
    it { should exist }
    its('lifecycle_state') { should eq 'ACTIVE' }
  end
end
