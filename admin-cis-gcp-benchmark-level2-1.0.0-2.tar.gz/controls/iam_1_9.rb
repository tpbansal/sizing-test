# frozen_string_literal: true

title 'Ensure that Separation of duties is enforced while assigning KMS related roles to users'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-iam-1.9' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure that Separation of duties is enforced while assigning KMS related roles to users.'
  desc '
  It is recommended that principle of Separation of duties is enforced while assigning KMS related roles to users.

  Rationale:
  Built-in/Predefined IAM role Cloud KMS Admin allows user/identity to create, delete, and manage service
  account(s). Built-in/Predefined IAM role Cloud KMS CryptoKey Encrypter/Decrypter allows user/identity (with
  adequate privileges on concerned resources) to encrypt and decrypt data at rest using encryption key(s).
  Built-in/Predefined IAM role Cloud KMS CryptoKey Encrypter allows user/identity (with adequate privileges on
  concerned resources) to encrypt data at rest using encryption key(s). Built- in/Predefined IAM role Cloud KMS
  CryptoKey Decrypter allows user/identity (with adequate privileges on concerned resources) to decrypt data at
  rest using encryption key(s).

  Separation of duties is the concept of ensuring that one individual does not have all necessary permissions to be
  able to complete a malicious action. In Cloud KMS, this could be an action such as using a key to access and decrypt
  data that that user should not normally have access to. Separation of duties is a business control typically used in
  larger organizations, meant to help avoid security or privacy incidents and errors. It is considered best practice.

  Any user(s) should not have Cloud KMS Admin and any of the Cloud KMS CryptoKey Encrypter/Decrypter, Cloud KMS
  CryptoKey Encrypter, Cloud KMS CryptoKey Decrypter roles assigned at a time.
  '
  tag cis: 'gcp:1.9'
  tag level: 2

  # First get the users having the KMS Admin role
  kms_administrators = google_project_iam_binding(project: gcp_project_id, role: 'roles/cloudkms.admin').members
  # Now check whether others contain Admins
  describe google_project_iam_binding(project: gcp_project_id, role: 'roles/cloudkms.cryptoKeyEncrypterDecrypter') do
    kms_administrators.each do |admin|
      its('members.to_s') { should_not match admin }
    end
  end

  describe google_project_iam_binding(project: gcp_project_id, role: 'roles/cloudkms.cryptoKeyEncrypter') do
    kms_administrators.each do |admin|
      its('members.to_s') { should_not match admin }
    end
  end

  describe google_project_iam_binding(project: gcp_project_id, role: 'roles/cloudkms.cryptoKeyDecrypter') do
    kms_administrators.each do |admin|
      its('members.to_s') { should_not match admin }
    end
  end
end
