# frozen_string_literal: true

title 'Ensure Automatic node upgrades is enabled on Kubernetes Engine Clusters nodes'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-kubernetes-7.9' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure Automatic node upgrades is enabled on Kubernetes Engine Clusters nodes'
  desc '
  Container-Optimized OS is an operating system image for your Compute Engine VMs that is optimized for running Docker
  containers. With Container-Optimized OS, you can bring up your Docker containers on Google Cloud Platform quickly,
  efficiently, and securely.

  Rationale:
  The Container-Optimized OS node image is based on a recent version of the Linux kernel and is optimized to enhance
  node security. It is backed by a team at Google that can quickly patch it for security and iterate on features. The
  Container-Optimized OS image provides better support, security, and stability than previous images.
  Container-Optimized OS requires Kubernetes version 1.4.0 or higher.

  Enabling Container-Optimized OS provides the following benefits:
  - Run Containers Out of the Box: Container-Optimized OS instances come pre- installed with the Docker runtime and cloud-init. With a Container-Optimized OS instance, you can bring up your Docker container at the same time you create your VM, with no on-host setup required.
  - Smaller attack surface: Container-Optimized OS has a smaller footprint, reducing your instance\'s potential
    attack surface.
  - Locked-down by default: Container-Optimized OS instances include a locked-down firewall and other security
    settings by default.
  - Automatic Updates: Container-Optimized OS instances are configured to automatically download weekly updates in the
    background; only a reboot is necessary to use the latest updates.
  '
  tag cis: 'gcp:7.9'
  tag level: 2

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      google_container_node_pools(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name).node_pool_names.each do |node_pool_name|
        describe google_container_node_pool(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name, nodepool_name: node_pool_name) do
          its('config_image_type') { should eq 'COS' }
        end
      end
    end
  end
end
