# frozen_string_literal: true

title 'Ensure Stackdriver Monitoring is set to Enabled on Kubernetes Engine Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.2' do
  impact 1.0
  title 'Ensure Stackdriver Monitoring is set to Enabled on Kubernetes Engine Clusters'
  desc '
  Stackdriver Monitoring to monitor signals and build operations in your Kubernetes Engine clusters. Stackdriver
  Monitoring can access metrics about CPU utilization, some disk traffic metrics, network traffic, and uptime
  information. Stackdriver Monitoring uses the Monitoring agent to access additional system resources and application
  services in virtual machine instances.

  Rationale:
  By Enabling Stackdriver Monitoring you will have system metrics and custom metrics. System metrics are
  measurements of the cluster\'s infrastructure, such as CPU or memory usage. For system metrics, Stackdriver
  creates a Deployment that periodically connects to each node and collects metrics about its Pods and containers,
  then sends the metrics to Stackdriver. Metrics for usage of system resources are collected from the CPU, Memory,
  Evictable memory, Non-evictable memory, and Disk sources.
  '
  tag cis: 'gcp:7.2'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_monitoring_enabled }
      end
    end
  end
end
