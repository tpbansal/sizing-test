# frozen_string_literal: true

title 'Ensure that instances are not configured to use the default service account with full access to all Cloud APIs'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-vms-4.1' do
  impact 1.0
  title 'Ensure that instances are not configured to use the default service account with full access to all Cloud APIs'
  desc '
  To support principle of least privileges and prevent potential privilege escalation it is recommended that instances
  are not assigned to default service account Compute Engine default service account with Scope Allow full access to
  all Cloud APIs.

  Rationale:
  Along with ability to optionally create, manage and use user managed custom service accounts, Google Compute Engine
  provides default service account Compute Engine default service account for an instances to access necessary cloud
  services. Project Editor role is assigned to Compute Engine default service account hence, This service account has
  almost all capabilities over all cloud services except billing. However, when Compute Engine default service account
  assigned to an instance it can operate in 3 scopes.
  1. Allow default access: Allows only minimum access required to run an Instance (Least Privileges)
  2. Allow full access to all Cloud APIs: Allow full access to all the cloud APIs/Services (Too much access)
  3. Set access for each API: Allows Instance administrator to choose only those APIs that are needed to perform
     specific business functionality expected by instance

  When an instance is configured with Compute Engine default service account with Scope Allow full access to all Cloud
  APIs, based on IAM roles assigned to the user(s) accessing Instance, it may allow user to perform cloud
  operations/API calls that user is not supposed to perform leading to successful privilege escalation.
  '
  tag cis: 'gcp:4.1'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_compute_instances(project: gcp_project_id, zone: zone_name).instance_names.each do |instance_name|
      describe google_compute_instance(project: gcp_project_id, zone: zone_name, name: instance_name) do
        its('service_account_scopes') { should_not include 'https://www.googleapis.com/auth/cloud-platform' }
      end
    end
  end
end
