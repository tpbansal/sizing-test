# frozen_string_literal: true

title 'Ensure Master authorized networks is set to Enabled on Kubernetes Engine Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.4' do
  impact 1.0
  title 'Ensure Master authorized networks is set to Enabled on Kubernetes Engine Clusters'
  desc '
  Authorized networks are a way of specifying a restricted range of IP addresses that are permitted to access your
  container cluster\'s Kubernetes master endpoint. Kubernetes Engine uses both Transport Layer Security (TLS) and
  authentication to provide secure access to your container cluster\'s Kubernetes master endpoint from the public
  internet. This provides you the flexibility to administer your cluster from anywhere; however, you might want to
  further restrict access to a set of IP addresses that you control. You can set this restriction by specifying an
  authorized network.

  Rationale:
  By Enabling, Master authorized networks blocks untrusted IP addresses from outside Google Cloud Platform and
  Addresses from inside GCP (such as traffic from Compute Engine VMs) can reach your master through HTTPS provided
  that they have the necessary Kubernetes credentials.

  Restricting access to an authorized network can provide additional security benefits for your container
  cluster, including:
  - Better Protection from Outsider Attacks: Authorized networks provide an additional layer of security by
    limiting external, non-GCP access to a specific set of addresses you designate, such as those that originate
    from your premises. This helps protect access to your cluster in the case of a vulnerability in the
    cluster\'s authentication or authorization mechanism.
  - Better Protection from Insider Attacks: Authorized networks help protect your cluster from accidental leaks of
    master certificates from your company\'s premises. Leaked certificates used from outside GCP and outside the
    authorized IP ranges--for example, from addresses outside your company--are still denied access.
  '
  tag cis: 'gcp:7.4'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_master_authorized_networks_enabled }
      end
    end
  end
end
