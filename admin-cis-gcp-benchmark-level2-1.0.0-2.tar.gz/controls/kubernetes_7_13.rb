# frozen_string_literal: true

title 'Ensure Kubernetes Cluster is created with Alias IP ranges enabled'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.13' do
  impact 1.0
  title 'Ensure Kubernetes Cluster is created with Alias IP ranges enabled'
  desc '
  Google Cloud Platform Alias IP Ranges lets you assign ranges of internal IP addresses as aliases to a virtual
  machine\'s network interfaces. This is useful if you have multiple services running on a VM and you want to assign
  each service a different IP address.

  Rationale:
  With Alias IPs ranges enabled, Kubernetes Engine clusters can allocate IP addresses from a CIDR block known to
  Google Cloud Platform. This makes your cluster more scalable and allows your cluster to better interact with other
  GCP products and entities. Using Alias IPs has several benefits:
  - Pod IPs are reserved within the network ahead of time, which prevents conflict with other compute resources.
  - The networking layer can perform anti-spoofing checks to ensure that egress traffic is not sent with arbitrary source IPs.
  - Firewall controls for Pods can be applied separately from their nodes.
  - Alias IPs allow Pods to directly access hosted services without using a NAT gateway.
  '
  tag cis: 'gcp:7.13'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_ip_alias_enabled }
      end
    end
  end
end
