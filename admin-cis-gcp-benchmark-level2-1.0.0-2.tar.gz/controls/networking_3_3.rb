# frozen_string_literal: true

title 'Ensure that DNSSEC is enabled for Cloud DNS'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-networking-3.3' do
  impact 1.0
  title 'Ensure that DNSSEC is enabled for Cloud DNS'
  desc '
  Cloud DNS is a fast, reliable and cost-effective Domain Name System that powers millions of domains on the
  internet. DNSSEC in Cloud DNS enables domain owners to take easy steps to protect their domains against DNS
  hijacking and man-in-the-middle and other attacks.

  Rationale:
  Domain Name System Security Extensions (DNSSEC) adds security to the Domain Name System (DNS) protocol by
  enabling DNS responses to be validated. Having a trustworthy Domain Name System (DNS) that translates a
  domain name like www.example.com into its associated IP address is an increasingly important building block of
  today\'s web-based applications. Attackers can hijack this process of domain/IP lookup and redirect users to a
  malicious site through DNS hijacking and man-in-the-middle attacks. DNSSEC helps mitigate the risk of such
  attacks by cryptographically signing DNS records. As a result, it prevents attackers from issuing fake DNS
  responses that may misdirect browsers to nefarious websites.
  '
  tag cis: 'gcp:3.3'
  tag level: 1

  describe google_dns_managed_zones(project: gcp_project_id).where(dnssec_config_state: false) do
    it { should_not exist }
  end
end
