# frozen_string_literal: true

title 'Ensure Kubernetes Clusters are configured with Labels'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.5' do
  impact 1.0
  title 'Ensure Kubernetes Clusters are configured with Labels'
  desc '
  A cluster label is a key-value pair that helps you organize your Google Cloud Platform resources, such as
  clusters. You can attach a label to each resource, then filter the resources based on their labels. Information
  about labels is forwarded to the billing system, so you can break down your billing charges by the label.

  Rationale:
  Configured Labels can be used to organize and to select subsets of objects. Labels can be attached to objects at
  creation time and subsequently added and modified at any time. Each object can have a set of key/value labels
  defined. Each Key must be unique for a given object. Labels enable users to map their own organizational structures
  onto system objects in a loosely coupled fashion, without requiring clients to store these mappings. Labels can also
  be used to apply specific security settings and \'auto configure\' objects at creation.
  '
  tag cis: 'gcp:7.5'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_resource_labels }
      end
    end
  end
end
