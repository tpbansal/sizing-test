# frozen_string_literal: true

title 'Ensure that corporate login credentials are used instead of Gmail accounts'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-iam-1.1' do
  impact 1.0
  title 'Use corporate login credentials instead of Gmail accounts.'
  desc '
  Gmail accounts are personally created and controllable accounts. Organizations seldom have any control over them.
  Thus, it is recommended that you use fully managed corporate Google accounts for increased visibility, auditing,
  and control over access to Cloud Platform resources.
  '
  tag cis: 'gcp:1.1'
  tag level: 1

  google_project_iam_bindings(project: gcp_project_id).iam_binding_roles.each do |iam_binding_role|
    describe google_project_iam_binding(project: gcp_project_id, role: iam_binding_role) do
      its('members.to_s') { should_not match 'gmail.com' }
    end
  end
end
