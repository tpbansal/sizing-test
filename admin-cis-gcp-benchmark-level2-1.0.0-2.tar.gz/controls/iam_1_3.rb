# frozen_string_literal: true

title 'Ensure that there are only GCP-managed service account keys for each service account'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-iam-1.3' do
  impact 1.0
  title 'User managed service account should not have user managed keys.'
  desc '
  Anyone who has access to the keys will be able to access resources through the service account. GCP-managed keys are
  used by Cloud Platform services such as App Engine and Compute Engine. These keys cannot be downloaded. Google will
  keep the keys and automatically rotate them on an approximately weekly basis. User-managed keys are created,
  downloadable, and managed by users. They expire 10 years from creation.

  For user-managed keys, User have to take ownership of key management activities which includes:
  * Key storage
  * Key distribution
  * Key revocation
  * Key rotation
  * Protecting the keys from unauthorized users
  * Key recovery Even after owners precaution, Keys can be easily leaked by common development malpractices like
    checking keys into the source code or leaving them in Downloads directory, antecedently leaving them on support blogs/channels.

  It is recommended to prevent use of User-managed service account keys.
  '
  tag cis: 'gcp:1.3'
  tag level: 1

  google_service_accounts(project: gcp_project_id).service_account_names.each do |service_account_name|
    describe google_service_account(name: service_account_name) do
      it { should_not have_user_managed_keys }
    end
  end
end
