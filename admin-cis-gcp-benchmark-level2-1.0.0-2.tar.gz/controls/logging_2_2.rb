# frozen_string_literal: true

title 'Ensure that sinks are configured for all Log entries'

gcp_project_id = attribute('gcp_project_id', default: '', description: 'The GCP project identifier.')

control 'cis-gcp-benchmark-logging-2.2' do
  impact 1.0
  title 'Ensure that sinks are configured for all Log entries'
  desc '
  It is recommended to create sink which will export copies of all the log entries.

  Rationale:
  Log entries are held in Stackdriver Logging for a limited time known as the retention period. After that, the
  entries are deleted. To keep log entries longer, sink can export them outside of Stackdriver Logging. Exporting
  involves writing a filter that selects the log entries to export, and choosing a destination in Cloud Storage,
  BigQuery, or Cloud Pub/Sub. The filter and destination are held in an object called a sink. To ensure all
  log entries are exported using sink ensure that there is no filter configured for a sink. Sinks can be created
  in projects, organizations, folders, and billing accounts.
  '
  tag cis: 'gcp:2.2'
  tag level: 1

  # Note this control is written for project level sinks
  describe google_logging_project_sinks(project: gcp_project_id).where(sink_filter: nil) do
    it { should exist }
  end

  describe google_logging_project_sinks(project: gcp_project_id).where(sink_filter: nil).where(sink_destination: nil) do
    it { should_not exist }
  end

end
