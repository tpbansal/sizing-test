# frozen_string_literal: true

title 'Ensure that IAM users are not assigned Service Account User role at project level'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-iam-1.5' do
  impact 1.0
  title 'Ensure that IAM users are not assigned Service Account User role at project level.'
  desc '
  It is recommended to assign Service Account User (iam.serviceAccountUser) role to a user for a
  specific service account rather than assigning the role to a user at project level.

  Rationale:
  Granting the iam.serviceAccountUser role to a user for a project gives the user access to all service accounts in
  the project, including service accounts that may be created in the future. This can result into elevation of
  privileges by using service accounts and corresponding Compute Engine instances.
  In order to implement least privileges best practices, IAM users should not be assigned Service Account User role
  at project level. Instead iam.serviceAccountUser role should be assigned to a user for a specific service account
  giving a user access to the service account.
  '
  tag cis: 'gcp:1.5'
  tag level: 1

  describe google_project_iam_bindings(project: gcp_project_id).where(iam_binding_role: 'roles/iam.serviceAccountUser') do
    it { should_not exist }
  end
end
