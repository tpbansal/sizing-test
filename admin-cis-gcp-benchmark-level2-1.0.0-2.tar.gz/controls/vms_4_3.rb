# frozen_string_literal: true

title 'Ensure oslogin is enabled for a Project'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-vms-4.3' do
  impact 1.0
  title 'Ensure oslogin is enabled for a Project'
  desc '
  Enabling OS login binds SSH certificates to IAM users and facilitates effective SSH certificate management.

  Rationale:
  Enabling osLogin ensures that SSH keys used to connect to instances are mapped with IAM users. Revoking access to
  IAM user will revoke all the SSH keys associated with that particular user. It facilitates centralized and
  automated SSH key pair management which is useful in handling cases like response to compromised SSH key
  pairs and/or revocation of external/third-party/Vendor users.
  '
  tag cis: 'gcp:4.3'
  tag level: 1

  describe google_compute_project_info(project: gcp_project_id) do
    it { should have_enabled_oslogin }
  end
end
