# frozen_string_literal: true

title 'Ensure that RDP access is restricted from the internet'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-networking-3.7' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure that RDP access is restricted from the internet'
  desc '
  GCP Firewall Rules are specific to a VPC Network. Each rule either allows or denies traffic when its conditions
  are met. Its conditions allow you to specify the type of traffic, such as ports and protocols, and the source or
  destination of the traffic, including IP addresses, subnets, and instances. Firewall rules are defined at the VPC
  network level, and are specific to the network in which they are defined. The rules themselves cannot be shared
  among networks. Firewall rules only support IPv4 traffic. When specifying a source for an ingress rule or a
  destination for an egress rule by address, you can only use an IPv4 address or IPv4 block in CIDR
  notation. Generic (0.0.0.0/0) incoming traffic from internet to VPC or VM instance using RDP on Port 3389
  can be avoided.

  Rationale:
  GCP Firewall Rules within a VPC Network. These rules apply to outgoing (egress) traffic from instances and
  incoming (ingress) traffic to instances in the network. Egress and ingress traffic are controlled even if the
  traffic stays within the network (for example, instance-to-instance communication). For an instance to have
  outgoing Internet access, the network must have a valid Internet gateway route or custom route whose destination IP
  is specified. This route simply defines the path to the Internet, to avoid the most general (0.0.0.0/0)
  destination IP Range specified from Internet through RDP with default Port 3389. We need to restrict generic
  access from Internet to specific IP Range.
  '
  tag cis: 'gcp:3.7'
  tag level: 2

  # Here the spec asks for source range not to include 0.0.0.0/0 across INGRESS and EGRESS
  google_compute_firewalls(project: gcp_project_id).firewall_names.each do |firewall_name|
    describe google_compute_firewall(project: gcp_project_id, name: firewall_name) do
      it { should_not allow_ip_ranges ['0.0.0.0/0'] }
    end
  end

  # Specifically for INGRESS, disallow RDP on port 3389
  google_compute_firewalls(project: gcp_project_id).where(firewall_direction: 'INGRESS').firewall_names.each do |firewall_name|
    describe google_compute_firewall(project: gcp_project_id, name: firewall_name) do
      it { should_not be_allowed_rdp }
    end
  end
end
