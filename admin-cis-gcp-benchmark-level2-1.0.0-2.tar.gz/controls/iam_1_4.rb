# frozen_string_literal: true

title 'Ensure that ServiceAccount has no Admin privileges.'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-iam-1.4' do
  impact 1.0
  title 'Ensure that ServiceAccount has no Admin privileges.'
  desc '
  A service account is a special Google account that belongs to your application or a VM, instead of to an
  individual end user. Your application uses the service account to call the Google API of a service, so that
  the users aren\'t directly involved, It\'s recommended not to use admin access for ServiceAccount.

  Rationale:
  Service accounts represent service-level security of the Resources (application or a VM) which can be determined
  by the roles assigned to it. Enrolling ServiceAccount with Admin rights gives full access to assigned application or a
  VM, ServiceAccount Access holder can perform critical actions like delete, update change settings etc. without the
  intervention of user, So It\'s recommended not to have Admin rights.
  This recommendation is applicable only for User-Managed user created service account (Service account with
  nomenclature: SERVICE_ACCOUNT_NAME@PROJECT_ID.iam.gserviceaccount.com).
  '
  tag cis: 'gcp:1.4'
  tag level: 1

  google_project_iam_bindings(project: gcp_project_id).where(iam_binding_role: /admin/).iam_binding_roles.each do |role|
    describe google_project_iam_binding(project: gcp_project_id, role: role) do
      its('members.to_s') { should_not match "@#{gcp_project_id}.iam.gserviceaccount.com" }
    end
  end

  google_project_iam_bindings(project: gcp_project_id).where(iam_binding_role: /Admin/).iam_binding_roles.each do |role|
    describe google_project_iam_binding(project: gcp_project_id, role: role) do
      its('members.to_s') { should_not match "@#{gcp_project_id}.iam.gserviceaccount.com" }
    end
  end

  google_project_iam_bindings(project: gcp_project_id).where(iam_binding_role: 'roles/editor').iam_binding_roles.each do |role|
    describe google_project_iam_binding(project: gcp_project_id, role: role) do
      its('members.to_s') { should_not match "@#{gcp_project_id}.iam.gserviceaccount.com" }
    end
  end

  google_project_iam_bindings(project: gcp_project_id).where(iam_binding_role: 'roles/owner').iam_binding_roles.each do |role|
    describe google_project_iam_binding(project: gcp_project_id, role: role) do
      its('members.to_s') { should_not match "@#{gcp_project_id}.iam.gserviceaccount.com" }
    end
  end
end
