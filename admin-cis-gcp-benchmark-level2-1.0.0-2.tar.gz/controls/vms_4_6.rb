# frozen_string_literal: true

title 'Ensure VM disks for critical VMs are encrypted with Customer- Supplied Encryption Keys (CSEK)'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-vms-4.6' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure that IP forwarding is not enabled on Instances'
  desc '
  Customer-Supplied Encryption Keys (CSEK) are a feature in Google Cloud Storage and Google Compute Engine. If you
  supply your own encryption keys, Google uses your key to protect the Google-generated keys used to encrypt and
  decrypt your data. By default, Google Compute Engine encrypts all data at rest. Compute Engine handles and manages
  this encryption for you without any additional actions on your part. However, if you wanted to control and
  manage this encryption yourself, you can provide your own encryption keys.

  Rationale:
  By default, Google Compute Engine encrypts all data at rest. Compute Engine handles and manages this encryption
  for you without any additional actions on your part. However, if you wanted to control and manage this
  encryption yourself, you can provide your own encryption keys.

  If you provide your own encryption keys, Compute Engine uses your key to protect the Google-generated keys used
  to encrypt and decrypt your data. Only users who can provide the correct key can use resources protected by a
  customer-supplied encryption key.

  Google does not store your keys on its servers and cannot access your protected data unless you provide the
  key. This also means that if you forget or lose your key, there is no way for Google to recover the key or to
  recover any data encrypted with the lost key.

  At least business critical VMs should have VM disks encrypted with CSEK.
  '
  tag cis: 'gcp:4.6'
  tag level: 2

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_compute_instances(project: gcp_project_id, zone: zone_name).instance_names.each do |instance_name|
      describe google_compute_instance(project: gcp_project_id, zone: zone_name, name: instance_name) do
        it { should have_disks_encrypted_with_csek }
      end
    end
  end
end
