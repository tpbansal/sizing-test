# frozen_string_literal: true

title 'Ensure that Cloud Audit Logging is configured properly across all services and all users from a project'

gcp_project_id = attribute('gcp_project_id', default: '', description: 'The GCP project identifier.')

control 'cis-gcp-benchmark-logging-2.1' do
  impact 1.0
  title 'Ensure that Cloud Audit Logging is configured properly across all services and all users from a project'
  desc '
  It is recommended that Cloud Audit Logging is configured to track all Admin activities and read, write access to
  user data.

  Rationale:
  Cloud Audit Logging maintains two audit logs for each project and organization: Admin Activity and Data Access.
  1. Admin Activity logs contain log entries for API calls or other administrative actions that modify the
  configuration or metadata of resources. Admin Activity audit logs are enabled for all services and cannot be
  configured.
  2. Data Access audit logs record API calls that create, modify, or read user-provided data. These are disabled by
  default and should be enabled.
  There are three kinds of Data Access audit log information:
  * Admin read: Records operations that read metadata or configuration information. Admin Activity audit logs record
  writes of metadata and configuration information which cannot be disabled.
  * Data read: Records operations that read user-provided data. o Data write: Records operations that write
  user-provided data.
  It is recommended to have effective default audit config configured in such a way that:
  1. logtype is set to DATA_READ (to logs user activity tracking) and DATA_WRITES (to log changes/tampering to
  user data)
  2. audit config is enabled for all the services supported by Data Access audit logs feature
  3. Logs should be captured for all users i.e.. there are no exempted users in any of the audit config section. This
  will ensure overriding audit config will not contradict the requirement.
  '
  tag cis: 'gcp:2.1'
  tag level: 1

  describe google_project_logging_audit_config(project: gcp_project_id) do
    its('default_types') { should include 'DATA_WRITE' }
    its('default_types') { should include 'DATA_READ' }
    it { should_not have_default_exempted_members }
  end

end
