# frozen_string_literal: true

title 'Ensure "Block Project-wide SSH keys" enabled for VM instances'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-vms-4.2' do
  impact 1.0
  title 'Ensure "Block Project-wide SSH keys" enabled for VM instances'
  desc '
  It is recommended to user Instance specific SSH key(s) instead of using common/shared project-wide SSH key(s)
  to access Instances.

  Rationale:
  Project-wide SSH keys are stored in Compute/Project-meta-data. Project wide SSH keys can be used to login
  into all the instances within project. Using project-wide SSH keys eases the SSH key management but if compromised,
  poses the security risk which can impact all the instances within project. It is recommended to use Instance
  specific SSH keys which can limit the attack surface if the SSH keys are compromised.
  '
  tag cis: 'gcp:4.2'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_compute_instances(project: gcp_project_id, zone: zone_name).instance_names.each do |instance_name|
      describe google_compute_instance(project: gcp_project_id, zone: zone_name, name: instance_name) do
        its('block_project_ssh_keys') { should eq true }
      end
    end
  end
end
