# frozen_string_literal: true

title 'Ensure legacy networks does not exists for a project'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-networking-3.2' do
  impact 1.0
  title 'Ensure legacy networks does not exists for a project'
  desc '
  In order to prevent use of legacy networks, a project should not have a legacy network configured.

  Rationale:
  Legacy networks have a single network IPv4 prefix range and a single gateway IP address for the whole
  network. The network is global in scope and spans all cloud regions. You cannot create subnetworks in a
  legacy network or switch from legacy to auto or custom subnet networks. Legacy networks can thus have an
  impact for high network traffic projects and subject to the single point of contention or failure.
  '
  tag cis: 'gcp:3.2'
  tag level: 1

  google_compute_networks(project: gcp_project_id).network_names.each do |network_name|
    describe google_compute_network(project: gcp_project_id, name: network_name) do
      it { should_not be_legacy }
    end
  end
end
