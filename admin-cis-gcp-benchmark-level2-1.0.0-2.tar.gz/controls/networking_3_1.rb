# frozen_string_literal: true

title 'Ensure the default network does not exist in a project'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-networking-3.1' do
  impact 1.0
  title 'Ensure the default network does not exist in a project'
  desc '
  The default network has automatically created firewall rules and has
  pre-fabricated network configuration. Based on your security and networking
  requirements, you should create your network and delete the default network.
  '
  tag cis: 'gcp:3.1'
  tag level: 1

  describe google_compute_networks(project: gcp_project_id) do
    its('network_names') { should_not include 'default' }
  end
end
