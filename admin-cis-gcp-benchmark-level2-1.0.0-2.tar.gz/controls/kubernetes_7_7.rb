# frozen_string_literal: true

title 'Ensure `Automatic node repair` is enabled for Kubernetes Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.7' do
  impact 1.0
  title 'Ensure `Automatic node repair` is enabled for Kubernetes Clusters'
  desc '
  Kubernetes Engine\'s node auto-repair feature helps you keep the nodes in your cluster in a healthy, running
  state. When enabled, Kubernetes Engine makes periodic checks on the health state of each node in your cluster. If
  a node fails consecutive health checks over an extended time period, Kubernetes Engine initiates a repair process
  for that node. If you disable node auto-repair at any time during the repair process, the in-progress repairs are
  not cancelled and still complete for any node currently under repair.

  Rationale:
  Kubernetes Engine uses the node\'s health status to determine if a node needs to be repaired. A node reporting
  a Ready status is considered healthy. Kubernetes Engine triggers a repair action if a node reports consecutive
  unhealthy status reports for a given time threshold. An unhealthy status can mean:                                                                                                                                                                                                                                                                                                                                         A node reports a NotReady status on consecutive checks over the given time threshold (approximately 10 minutes).
  - A node does not report any status at all over the given time threshold (approximately 10 minutes).
  - A node\'s boot disk is out of disk space for an extended time period (approximately 30 minutes).

  You can enable node auto-repair on a per-node pool basis. When you create a cluster, you can enable or disable
  auto-repair for the cluster\'s default node pool. If you create additional node pools, you can enable or disable
  node auto-repair for those node pools, independent of the auto-repair setting for the default node pool.
  Kubernetes Engine generates an entry in its operation logs for any automated repair event. You can check the
  logs by using the gcloud container operations list command.
  '
  tag cis: 'gcp:7.7'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      google_container_node_pools(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name).node_pool_names.each do |node_pool_name|
        describe google_container_node_pool(project: gcp_project_id, zone: zone_name, cluster_name: cluster_name, nodepool_name: node_pool_name) do
          it { should have_automatic_node_repair }
        end
      end
    end
  end
end
