# frozen_string_literal: true

title 'Ensure log metric filter and alerts exists for VPC network route changes'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-logging-2.8' do
  impact 1.0
  title 'Ensure log metric filter and alerts exists for VPC network route changes'
  desc '
  It is recommended that a metric filter and alarm be established for VPC network route changes.

  Rationale:
  Google Cloud Platform (GCP) routes define the paths network traffic takes from a VM instance to another
  destinations. The other destination can be inside your VPC network (such as another VM) or outside of
  it. Every route consists of a destination and a next hop. Traffic whose destination IP is within the destination
  range is sent to the next hop for delivery.
  Monitoring changes to route tables will help ensure that all VPC traffic flows through an expected path.
  '
  tag cis: 'gcp:2.8'
  tag level: 1

  filter = "resource.type=\"gce_route\" AND jsonPayload.event_subtype=\"compute.routes.delete\" OR jsonPayload.event_subtype=\"compute.routes.insert\"\n"
  describe google_project_metrics(project: gcp_project_id).where(metric_filter: filter) do
    it { should exist }
  end

  alert_policy_exists = false
  google_project_metrics(project: gcp_project_id).where(metric_filter: filter).metric_types.each do |metric_type|
    metric_filter = "metric.type=\"#{metric_type}\" project=\"#{gcp_project_id}\""
    google_project_alert_policies(project: gcp_project_id).where(policy_enabled_state: true).where { policy_filter_list.include?(metric_filter) }.policy_names.each do |policy_name|
      describe google_project_alert_policy_condition(policy: policy_name, filter: metric_filter) do
        alert_policy_exists=true
        it { should exist }
        its('condition_threshold_value') { should eq 0.001 }
        its('aggregation_alignment_period') { should eq '60s' }
        its('aggregation_cross_series_reducer') { should eq 'REDUCE_COUNT' }
        its('aggregation_per_series_aligner') { should eq 'ALIGN_RATE' }
      end
    end
  end

  describe alert_policy_exists do
    it "Alert policy for filter \"#{filter}\" does not exist" do
      expect(alert_policy_exists).to(be true)
    end
  end
end
