# frozen_string_literal: true

title 'Ensure Basic Authentication is disabled on Kubernetes Engine Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.10' do
  impact 1.0
  title 'Ensure Basic Authentication is disabled on Kubernetes Engine Clusters'
  desc '
  Basic authentication allows a user to authenticate to the cluster with a username and password and it is stored
  in plain text without any encryption. Disabling Basic authentication will prevent attacks like brute force. Its
  recommended to use either client certificate or IAM for authentication.

  Rationale:
  When disabled, you will still be able to authenticate to the cluster with client certificate or IAM. A client
  certificate is a base64-encoded public certificate used by clients to authenticate to the cluster endpoint. Disable
  client certificate generation to create a cluster without a client certificate.
  '
  tag cis: 'gcp:7.10'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should_not have_basic_authorization }
      end
    end
  end
end
