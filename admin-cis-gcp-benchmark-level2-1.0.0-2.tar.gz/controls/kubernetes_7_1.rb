# frozen_string_literal: true

title 'Ensure Stackdriver Logging is set to Enabled on Kubernetes Engine Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.1' do
  impact 1.0
  title 'Ensure Stackdriver Logging is set to Enabled on Kubernetes Engine Clusters'
  desc '
  Stackdriver Logging is part of the Stackdriver suite of products in Google Cloud Platform. It includes storage for
  logs, a user interface called the Logs Viewer, and an API to manage logs programmatically. Stackdriver Logging
  lets you have Kubernetes Engine automatically collect, process, and store your container and system logs in a
  dedicated, persistent datastore. Container logs are collected from your containers. System logs are collected from
  the cluster\'s components, such as docker and kubelet. Events are logs about activity in the cluster, such as the
  scheduling of Pods.

  Rationale:
  By Enabling you will have container and system logs, Kubernetes Engine deploys a per- node logging agent that reads
  container logs, adds helpful metadata, and then stores them. The logging agent checks for container logs in the
  following sources:
  - Standard output and standard error logs from containerized processes
  - kubelet and container runtime logs
  - Logs for system components, such as VM startup scripts

  For events, Kubernetes Engine uses a Deployment in the kube-system namespace which automatically collects events
  and sends them to Stackdriver Logging.

  Stackdriver Logging is compatible with JSON and glog formats. Logs are stored for up to 30 days.
  '
  tag cis: 'gcp:7.1'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_logging_enabled }
      end
    end
  end
end
