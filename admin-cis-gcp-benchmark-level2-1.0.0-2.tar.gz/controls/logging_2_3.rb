# frozen_string_literal: true

title 'Ensure that object versioning is enabled on log-buckets'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-logging-2.3' do
  impact 1.0
  title 'Ensure that object versioning is enabled on log-buckets'
  desc '
  It is recommended to enable object versioning on log-buckets.

  Rationale:
  Logs can be exported by creating one or more sinks that include a logs filter and a destination. As Stackdriver
  Logging receives new log entries, they are compared against each sink. If a log entry matches a sink\'s filter,
  then a copy of the log entry is written to the destination.

  Sinks can be configured to export logs in Storage buckets. To support the retrieval of objects that are deleted or
  overwritten, Object Versioning feature should be enabled on all such storage buckets where sinks are configured.
  '
  tag cis: 'gcp:2.3'
  tag level: 1

  google_logging_project_sinks(project: gcp_project_id).where(sink_destination: /storage.googleapis.com/).sink_destinations.each do |bucket|
    describe google_storage_bucket(name: bucket.split('/').last) do
      it { should have_versioning_enabled }
    end
  end
end
