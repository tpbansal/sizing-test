# frozen_string_literal: true

title 'Ensure Private Google Access is enabled for all subnetwork in VPC Network'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-networking-3.8' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure Private Google Access is enabled for all subnetwork in VPC Network'
  desc '
  Private Google Access enables virtual machine instances on a subnet to reach Google APIs and services using an
  internal IP address rather than an external IP address. External IP addresses are routable and reachable over
  the Internet. Internal (private) IP addresses are internal to Google Cloud Platform and are not routable or
  reachable over the Internet. You can use Private Google Access to allow VMs without Internet access to reach
  Google APIs, services, and properties that are accessible over HTTP/HTTPS.

  Rationale:
  VPC networks and subnetworks provide logically isolated and secure network partitions where you can launch GCP
  resources. When Private Google Access is enabled, VM instances in a subnet can reach the Google Cloud and Developer
  APIs and services without needing an external IP address. Instead, VMs can use their internal IP addresses to access
  Google managed services. Instances with external IP addresses are not affected when you enable the ability to
  access Google services from internal IP addresses. These instances can still connect to Google APIs and
  managed services.
  '
  tag cis: 'gcp:3.8'
  tag level: 2

  google_compute_regions(project: gcp_project_id).region_names.each do |region_name|
    google_compute_subnetworks(project: gcp_project_id, region: region_name).subnetwork_names.each do |subnetwork_name|
      describe google_compute_subnetwork(project: gcp_project_id, region: region_name, name: subnetwork_name) do
        its('private_ip_google_access') { should be true }
      end
    end
  end
end
