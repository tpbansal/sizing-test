# frozen_string_literal: true

title 'Ensure that IP forwarding is not enabled on Instances'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-vms-4.5' do
  impact 1.0
  title 'Ensure that IP forwarding is not enabled on Instances'
  desc '
  Compute Engine instance cannot forward a packet unless the source IP address of the packet matches the IP address
  of the instance. Similarly, GCP won\'t deliver a packet whose destination IP address is different than the IP
  address of the instance receiving the packet. However, both capabilities are required if you want to use
  instances to help route packets.

  Forwarding of data packets should be disabled to prevent data loss or information disclosure.

  Rationale:
  Compute Engine instance cannot forward a packet unless the source IP address of the packet matches the IP
  address of the instance. Similarly, GCP won\'t deliver a packet whose destination IP address is different
  than the IP address of the instance receiving the packet. However, both capabilities are required if you want
  to use instances to help route packets. To enable this source and destination IP check, disable the canIpForward
  field, which allows an instance to send and receive packets with non-matching destination or source IPs.
  '
  tag cis: 'gcp:4.5'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_compute_instances(project: gcp_project_id, zone: zone_name).instance_names.each do |instance_name|
      describe google_compute_instance(project: gcp_project_id, zone: zone_name, name: instance_name) do
        its('can_ip_forward') { should be false }
      end
    end
  end
end
