# frozen_string_literal: true

title 'Ensure Legacy Authorization is set to Disabled on Kubernetes Engine Clusters'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.3' do
  impact 1.0
  title 'Ensure Legacy Authorization is set to Disabled on Kubernetes Engine Clusters'
  desc '
  In Kubernetes, authorizers interact by granting a permission if any authorizer grants the permission. The
  legacy authorizer in Kubernetes Engine grants broad, statically defined permissions. To ensure that RBAC limits
  permissions correctly, you must disable the legacy authorizer. RBAC has significant security advantages, can
  help you ensure that users only have access to cluster resources within their own namespace and is now
  stable in Kubernetes.

  Rationale:
  Enable Legacy Authorization for in-cluster permissions that support existing clusters or workflows. Disable
  legacy authorization for full RBAC support for in-cluster permissions. In Kubernetes, RBAC is used to grant
  permissions to resources at the cluster and namespace level. RBAC allows you to define roles with rules
  containing a set of permissions.
  '
  tag cis: 'gcp:7.3'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_legacy_abac_disabled }
      end
    end
  end
end
