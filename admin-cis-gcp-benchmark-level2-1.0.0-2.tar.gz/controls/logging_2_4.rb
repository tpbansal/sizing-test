# frozen_string_literal: true

title 'Ensure log metric filter and alerts exists for Project Ownership assignments/changes'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-logging-2.4' do
  impact 1.0
  title 'Ensure log metric filter and alerts exists for Project Ownership assignments/changes'
  desc '
  In order to prevent unnecessarily project ownership assignments to users/service- accounts and further misuses
  of project and resources, all roles/Owner assignments should be monitored.
  Members (users/Service-Accounts) with role assignment to primitive role roles/owner are Project Owners.

  Project Owner has all the privileges on a project it belongs to. These can be summarized as below:
  - All viewer permissions on All GCP Services part within the project
  - Permissions for actions that modify state of All GCP Services within the project
  - Manage roles and permissions for a project and all resources within the project
  - Set up billing for a project

  Granting owner role to a member (user/Service-Account) will allow members to modify the IAM policy. Therefore grant
  the owner role only if the member has a legitimate purpose to manage the IAM policy. This is because as project IAM
  policy contains sensitive access control data and having a minimal set of users manage it will simplify any auditing
  that you may have to do.

  Rationale:
  Project Ownership Having highest level of privileges on a project, to avoid misuse of project resources project
  ownership assignment/change actions mentioned should be monitored and alerted to concerned recipients.
  - Sending project ownership Invites
  - Acceptance/Rejection of project ownership invite by user
  - Adding `role\owner` to a user/service-account
  - Removing a user/Service account from `role\owner`
  '
  tag cis: 'gcp:2.4'
  tag level: 1

  filter = "(protoPayload.serviceName=\"cloudresourcemanager.googleapis.com\") AND (ProjectOwnership OR projectOwnerInvitee) OR (protoPayload.serviceData.policyDelta.bindingDeltas.action=\"REMOVE\" AND\nprotoPayload.serviceData.policyDelta.bindingDeltas.role=\"roles/owner\") OR (protoPayload.serviceData.policyDelta.bindingDeltas.action=\"ADD\" AND protoPayload.serviceData.policyDelta.bindingDeltas.role=\"roles/owner\")\n"
  describe google_project_metrics(project: gcp_project_id).where(metric_filter: filter) do
    it { should exist }
  end

  alert_policy_exists = false
  google_project_metrics(project: gcp_project_id).where(metric_filter: filter).metric_types.each do |metric_type|
    metric_filter = "metric.type=\"#{metric_type}\" project=\"#{gcp_project_id}\""
    google_project_alert_policies(project: gcp_project_id).where(policy_enabled_state: true).where { policy_filter_list.include?(metric_filter) }.policy_names.each do |policy_name|
      describe google_project_alert_policy_condition(policy: policy_name, filter: metric_filter) do
        alert_policy_exists=true
        it { should exist }
        its('condition_threshold_value') { should eq 0.001 }
        its('aggregation_alignment_period') { should eq '60s' }
        its('aggregation_cross_series_reducer') { should eq 'REDUCE_COUNT' }
        its('aggregation_per_series_aligner') { should eq 'ALIGN_RATE' }
      end
    end
  end

  describe alert_policy_exists do
    it "Alert policy for filter \"#{filter}\" does not exist" do
      expect(alert_policy_exists).to(be true)
    end
  end
end
