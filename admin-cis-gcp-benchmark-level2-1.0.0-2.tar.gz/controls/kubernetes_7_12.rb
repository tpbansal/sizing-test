# frozen_string_literal: true

title 'Ensure Kubernetes Cluster is created with Client Certificate enabled'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-kubernetes-7.12' do
  impact 1.0
  title 'Ensure Kubernetes Cluster is created with Client Certificate enabled'
  desc '
  A client certificate is a base64-encoded public certificate used by clients to authenticate to the cluster endpoint.

  Rationale:
  If you disable client certificate generation to create a cluster without a client certificate. You will still be
  able to authenticate to the cluster with basic auth or IAM. But basic auth allows a user to authenticate to the
  cluster with a username and password which are stored in plain text without any encryption and might lead
  brute force attacks.
  '
  tag cis: 'gcp:7.12'
  tag level: 1

  google_compute_zones(project: gcp_project_id).zone_names.each do |zone_name|
    google_container_clusters(project: gcp_project_id, zone: zone_name).cluster_names.each do |cluster_name|
      describe google_container_cluster(project: gcp_project_id, zone: zone_name, name: cluster_name) do
        it { should have_master_auth_client_key }
      end
    end
  end
end
