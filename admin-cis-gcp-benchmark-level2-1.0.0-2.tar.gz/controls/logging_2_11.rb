# frozen_string_literal: true

title 'Ensure log metric filter and alerts exists for SQL instance configuration changes'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-logging-2.11' do
  impact 1.0
  title 'Ensure log metric filter and alerts exists for SQL instance configuration changes'
  desc '
  It is recommended that a metric filter and alarm be established for SQL Instance configuration changes.

  Rationale:
  Monitoring changes to Sql Instance configuration changes may reduce time to detect and correct
  misconfigurations done on sql server.
  Below are the few of configurable Options which may impact security posture of a SQL Instance:
   - Enable auto backups and high availability: Misconfiguration may adversely impact Business continuity,
     Disaster Recovery and High Availability
   - Authorize networks : Misconfiguration may increase exposure to the untrusted networks
  '
  tag cis: 'gcp:2.11'
  tag level: 1

  filter = "protoPayload.methodName=\"cloudsql.instances.update\"\n"
  describe google_project_metrics(project: gcp_project_id).where(metric_filter: filter) do
    it { should exist }
  end

  alert_policy_exists = false
  google_project_metrics(project: gcp_project_id).where(metric_filter: filter).metric_types.each do |metric_type|
    metric_filter = "metric.type=\"#{metric_type}\" project=\"#{gcp_project_id}\""
    google_project_alert_policies(project: gcp_project_id).where(policy_enabled_state: true).where { policy_filter_list.include?(metric_filter) }.policy_names.each do |policy_name|
      describe google_project_alert_policy_condition(policy: policy_name, filter: metric_filter) do
        alert_policy_exists=true
        it { should exist }
        its('condition_threshold_value') { should eq 0.001 }
        its('aggregation_alignment_period') { should eq '60s' }
        its('aggregation_cross_series_reducer') { should eq 'REDUCE_COUNT' }
        its('aggregation_per_series_aligner') { should eq 'ALIGN_RATE' }
      end
    end
  end

  describe alert_policy_exists do
    it "Alert policy for filter \"#{filter}\" does not exist" do
      expect(alert_policy_exists).to(be true)
    end
  end
end
