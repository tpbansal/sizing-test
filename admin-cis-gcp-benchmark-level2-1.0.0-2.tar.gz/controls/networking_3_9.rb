# frozen_string_literal: true

title 'Ensure VPC Flow logs is enabled for every subnet in VPC Network'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-networking-3.9' do
  impact 1.0
  title 'Ensure VPC Flow logs is enabled for every subnet in VPC Network'
  desc '
  Flow Logs is a feature that enables you to capture information about the IP traffic going to and from network
  interfaces in your VPC Subnets. After you\'ve created a flow log, you can view and retrieve its data in
  Stackdriver Logging. It is recommended that Flow Logs be enabled for every business critical VPC subnet.

  Rationale:
  VPC networks and subnetworks provide logically isolated and secure network partitions where you can launch
  GCP resources. When Flow Logs is enabled for a subnet, VMs within subnet starts reporting on all TCP and UDP
  flows. Each VM samples the TCP and UDP flows it sees, inbound and outbound, whether the flow is to or from
  another VM, a host in your on-premises datacenter, a Google service, or a host on the Internet. If two GCP
  VMs are communicating, and both are in subnets that have VPC Flow Logs enabled, both VMs report the flows.

  Flow Logs supports following use cases:
  - Network monitoring
  - Understanding network usage and optimizing network traffic expenses
  - Network forensics
  - Real-time security analysis
  Flow Logs provide visibility into network traffic for each VM inside the subnet and can be used to detect
  anomalous traffic or insight during security workflows.
  '
  tag cis: 'gcp:3.9'
  tag level: 1

  google_compute_regions(project: gcp_project_id).region_names.each do |region_name|
    describe google_compute_subnetworks(project: gcp_project_id, region: region_name).where(enable_flow_log: false) do
      it { should_not exist }
    end
  end
end
