# frozen_string_literal: true

title 'Ensure log metric filter and alerts exists for Custom Role changes'

gcp_project_id = attribute('gcp_project_id')

control 'cis-gcp-benchmark-logging-2.6' do
  impact 1.0
  title 'Ensure log metric filter and alerts exists for Custom Role changes'
  desc '
  It is recommended that a metric filter and alarm be established for changes IAM Role creation,
  deletion and updating activities.

  Rationale:
  Google Cloud Identity and Access Management (Cloud IAM) provides predefined roles that give granular access
  to specific Google Cloud Platform resources and prevent unwanted access to other resources. However to cater
  organization specific needs, Cloud IAM also provides ability to create custom roles. Project Owner and
  administrators with Organization Role Administrator role or the IAM Role Administrator role can create custom
  roles. Monitoring role creation, deletion and updating activities will help in identifying over-privileged
  role at early stages.
  '
  tag cis: 'gcp:2.6'
  tag level: 1

  filter = "resource.type=\"iam_role\" AND protoPayload.methodName = \"google.iam.admin.v1.CreateRole\" OR protoPayload.methodName=\"google.iam.admin.v1.DeleteRole\" OR protoPayload.methodName=\"google.iam.admin.v1.UpdateRole\"\n"
  describe google_project_metrics(project: gcp_project_id).where(metric_filter: filter) do
    it { should exist }
  end

  alert_policy_exists = false
  google_project_metrics(project: gcp_project_id).where(metric_filter: filter).metric_types.each do |metric_type|
    metric_filter = "metric.type=\"#{metric_type}\" project=\"#{gcp_project_id}\""
    google_project_alert_policies(project: gcp_project_id).where(policy_enabled_state: true).where { policy_filter_list.include?(metric_filter) }.policy_names.each do |policy_name|
      describe google_project_alert_policy_condition(policy: policy_name, filter: metric_filter) do
        alert_policy_exists=true
        it { should exist }
        its('condition_threshold_value') { should eq 0.001 }
        its('aggregation_alignment_period') { should eq '60s' }
        its('aggregation_cross_series_reducer') { should eq 'REDUCE_COUNT' }
        its('aggregation_per_series_aligner') { should eq 'ALIGN_RATE' }
      end
    end
  end

  describe alert_policy_exists do
    it "Alert policy for filter \"#{filter}\" does not exist" do
      expect(alert_policy_exists).to(be true)
    end
  end
end
