# frozen_string_literal: true

title 'Ensure that Separation of duties is enforced while assigning service account related roles to users'

gcp_project_id = attribute('gcp_project_id')
cis_level = attribute('cis_level')

control 'cis-gcp-benchmark-iam-1.7' do
  only_if { cis_level == 2 }
  impact 1.0
  title 'Ensure that Separation of duties is enforced while assigning service account related roles to users.'
  desc '
  A service account is a special Google account that belongs to your application or a VM, instead of to an
  individual end user. Your application uses the service account to call the Google API of a service, so that
  the users aren\'t directly involved, It\'s recommended not to use admin access for ServiceAccount.

  Rationale:
  Service accounts represent service-level security of the Resources (application or a VM) which can be determined
  by the roles assigned to it. Enrolling ServiceAccount with Admin rights gives full access to assigned application or a
  VM, ServiceAccount Access holder can perform critical actions like delete, update change settings etc. without the
  intervention of user, So It\'s recommended not to have Admin rights.
  This recommendation is applicable only for User-Managed user created service account (Service account with
  nomenclature: SERVICE_ACCOUNT_NAME@PROJECT_ID.iam.gserviceaccount.com).
  It is recommended that principle of Separation of duties is enforced while assigning service account
  related roles to users.

  Rationale:
  Built-in/Predefined IAM role Service Account admin allows user/identity to create, delete, manage service
  account(s). Built-in/Predefined IAM role Service Account User allows user/identity (with adequate privileges on
  Compute and App Engine) to assign service account(s) to Apps/Compute Instances.

  Separation of duties is the concept of ensuring that one individual does not have all necessary permissions to be
  able to complete a malicious action. In Cloud IAM - service accounts, this could be an action such as using a service
  account to access resources that user should not normally have access to. Separation of duties is a business control
  typically used in larger organizations, meant to help avoid security or privacy incidents and errors. It is
  considered best practice.

  Any user(s) should not have Service Account Admin and Service Account User, both roles assigned at a time.
  '
  tag cis: 'gcp:1.7'
  tag level: 2

  # First get the users having the Service Account Admin role (normally fewer than those having the equivalent User role)
  service_account_administrators = google_project_iam_binding(project: gcp_project_id, role: 'roles/iam.serviceAccountAdmin').members
  # Now check whether Users contain Admins
  describe google_project_iam_binding(project: gcp_project_id, role: 'roles/iam.serviceAccountUser') do
    service_account_administrators.each do |admin|
      its('members.to_s') { should_not match admin }
    end
  end
end
